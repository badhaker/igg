package com.innovationm.igotgame.Enum;

public enum FilterRecruiterValue {
ALL, ACTIVE, INACTIVE
}
