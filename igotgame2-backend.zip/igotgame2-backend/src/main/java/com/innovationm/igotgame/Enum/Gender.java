package com.innovationm.igotgame.Enum;

public enum Gender {
	
	MALE,FEMALE,OTHER

}
