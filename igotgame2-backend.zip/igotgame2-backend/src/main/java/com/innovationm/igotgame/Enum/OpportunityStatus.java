package com.innovationm.igotgame.Enum;

public enum OpportunityStatus {
OPEN,AWARDED,CLOSED
}
