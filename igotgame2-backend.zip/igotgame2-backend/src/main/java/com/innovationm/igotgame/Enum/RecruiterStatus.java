package com.innovationm.igotgame.Enum;

public enum RecruiterStatus {
ACTIVE, INACTIVE
}
