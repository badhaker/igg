package com.innovationm.igotgame.Enum;

public enum TokenType {

	RESET_PASSWORD, EMAIL_VERIFICATION, MOBILE_OTP;
}
