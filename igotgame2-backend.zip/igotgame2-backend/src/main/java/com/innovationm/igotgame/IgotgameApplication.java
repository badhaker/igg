package com.innovationm.igotgame;

import java.util.Properties;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovationm.igotgame.constant.AppConstants;

@SpringBootApplication
@EnableScheduling
@Configuration
public class IgotgameApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		new SpringApplicationBuilder(IgotgameApplication.class)
				.sources(IgotgameApplication.class)
				//.properties(getProperties())
				.run(args);

	}
	
//	@Override
//	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
//		return builder
//				.sources(IgotgameApplication.class)
//				.properties(getProperties());
//	}
//	 
//	static Properties getProperties() {
//		Properties props = new Properties();
//		props.put("spring.config.location", AppConstants.Config.APPLICATION_PROPERTY_SOURCE_PATH);
//		return props;
//	}
	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedOrigins("*").allowedHeaders("*");
			}
		};
	}
	
	@Bean
	public ObjectMapper objectMapper() {
	    return new ObjectMapper();
	}	
	
	@Bean
	public PasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}	
}
