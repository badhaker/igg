package com.innovationm.igotgame.advice;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.amazonaws.AmazonClientException;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.innovationm.igotgame.annotation.RequestLogger;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.exception.AppException;
import com.innovationm.igotgame.exception.AppUpGradationException;
import com.innovationm.igotgame.exception.CountryNotFoundException;
import com.innovationm.igotgame.exception.EmailNotVerifiedException;
import com.innovationm.igotgame.exception.EntityNotExistException;
import com.innovationm.igotgame.exception.FileStorageException;
import com.innovationm.igotgame.exception.InvalidInputException;
import com.innovationm.igotgame.exception.MasterStateNotFoundException;
import com.innovationm.igotgame.exception.NoSkillFoundException;
import com.innovationm.igotgame.exception.TokenAlreadyVerifiedException;
import com.innovationm.igotgame.exception.UnableToSendEmailException;
import com.innovationm.igotgame.exception.UserAlreadyExistException;
import com.innovationm.igotgame.exception.UserDetailsNotFoundException;
import com.innovationm.igotgame.exception.UserNotFoundException;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.security.TokenNotValidException;
import io.jsonwebtoken.JwtException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


@ControllerAdvice
public class UniversalControllerAdvice extends ResponseEntityExceptionHandler {
	private final Logger logger = LogManager.getLogger(this.getClass());
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@ExceptionHandler(AppException.class)
	public ResponseEntity<BaseApiResponse> exception(AppException appException, HttpServletRequest request) {
		logger.error(appException.getMessage());
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
		baseApiResponse.setResponseData(appException);
		//baseApiResponse.setMessage(appException.getMessage());
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	    @ExceptionHandler(UserAlreadyExistException.class)
	    public ResponseEntity<BaseApiResponse> handleUserAlreadyExistsException(
	            UserAlreadyExistException userAlreadyExistException, HttpServletRequest request) {
	    	logger.error(userAlreadyExistException.getMessage());
		 BaseApiResponse baseApiResponse = new BaseApiResponse();
			baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
			baseApiResponse.setResponseData(userAlreadyExistException);
			//baseApiResponse.setMessage(appException.getMessage());
			return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@ExceptionHandler(EntityNotExistException.class)
	public ResponseEntity<BaseApiResponse> entityNotExistException(EntityNotExistException entityNotExistException, HttpServletRequest request) {
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		logger.error(entityNotExistException.getMessage());
		baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
		baseApiResponse.setResponseData(entityNotExistException);
		//baseApiResponse.setMessage(entityNotExistException.getMessage());
		return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	}
	
	 @Override
	    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
	                                                                  HttpHeaders headers, HttpStatus status, WebRequest request) {
		 logger.error(ex.getMessage());
	        List<FieldError> allBindingErrorsList = ex.getBindingResult().getFieldErrors();
	        List<String> allBindingErrorsMessageList = new ArrayList<String>();

	        for (FieldError error : allBindingErrorsList) {
	            allBindingErrorsMessageList.add(error.getField() + " - " + error.getDefaultMessage());
	        }

	        BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);

	        InvalidInputException invalidInputException = new InvalidInputException(
	                AppConstants.ErrorType.INVALID_INPUT_ERROR, AppConstants.ErrorCodes.INVALID_INPUT_ERROR_CODE,
	                allBindingErrorsMessageList.toString());

	        baseApiResponse.setResponseData(invalidInputException);

	        return new ResponseEntity<Object>(baseApiResponse, HttpStatus.BAD_REQUEST);
	    }
	  @Override
      protected ResponseEntity<Object> handleHttpMessageNotReadable(
          HttpMessageNotReadableException ex, HttpHeaders headers,
          HttpStatus status, WebRequest request) {
		  logger.error(ex.getMessage());
		  BaseApiResponse baseApiResponse = new BaseApiResponse();
			baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
			//baseApiResponse.setResponseData(appException);
			baseApiResponse.setMessage("Request is Incorrect Please check");
			return new ResponseEntity<Object>(baseApiResponse, HttpStatus.BAD_REQUEST);
      }

		@ExceptionHandler(JsonMappingException.class)
		  @ResponseStatus(HttpStatus.BAD_REQUEST)
		public ResponseEntity<BaseApiResponse> handleJsonMappingException(JsonMappingException  ex) {
			logger.error(ex.getMessage());
			BaseApiResponse baseApiResponse = new BaseApiResponse();
			baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
			baseApiResponse.setMessage("Bad Request");
			return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.BAD_REQUEST);
		}
	    
	   
	    @ExceptionHandler(AuthenticationException.class)
	    public ResponseEntity<BaseApiResponse> handleAuthenticationException(
	            AuthenticationException entityNotPresentException, HttpServletRequest request) {
	    	logger.error(entityNotPresentException.getMessage());
	        BaseApiResponse baseApiResponse = new BaseApiResponse();
	        if (entityNotPresentException.getLocalizedMessage().equalsIgnoreCase(AppConstants.ErrorMessage.USER_DOES_NOT_EXISTS_ERROR_MESSAGE)) {
	            AppException appException = new AppException(
	                    AppConstants.ErrorType.SIGN_IN_ERROR, AppConstants.ErrorCodes.USER_DOES_NOT_EXISTS_ERROR_CODE, AppConstants.ErrorMessage.USER_DOES_NOT_EXISTS_ERROR_MESSAGE);
	            baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	            baseApiResponse.setResponseData(appException);
	        }
	//
	     
	        else if (entityNotPresentException.getLocalizedMessage().equalsIgnoreCase(AppConstants.ErrorMessage.USER_NOT_VERIFIED_ERROR_MESSAGE)) {
	            AppException appException = new AppException(
	                    AppConstants.ErrorType.SIGN_IN_ERROR, AppConstants.ErrorCodes.USER_NOT_VERIFIED_ERROR_CODE, AppConstants.ErrorMessage.USER_NOT_VERIFIED_ERROR_MESSAGE);
	            baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	            baseApiResponse.setResponseData(appException);
	        } 
	        else {
	            AppException appException = new AppException(
	                    AppConstants.ErrorType.SIGN_IN_ERROR, AppConstants.ErrorCodes.INVALID_CREDENTIALS_ERROR_CODE, AppConstants.ErrorMessage.INVALID_CREDENTIALS_ERROR_MESSAGE);

	            baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	            baseApiResponse.setResponseData(appException);
	        }
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @RequestLogger
	    @ExceptionHandler(EmailNotVerifiedException.class)
	    public ResponseEntity<BaseApiResponse> emailNotVerifiedException(
	            EmailNotVerifiedException emailNotVerifiedException, HttpServletRequest request) {
	    	logger.error(emailNotVerifiedException.getMessage());
	        BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(emailNotVerifiedException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @RequestLogger
	    @ExceptionHandler(JwtException.class)
	    public ResponseEntity<BaseApiResponse> tokenNotValidException(
	            JwtException tokenNotValidException, HttpServletRequest request) {
	    	logger.error(tokenNotValidException.getMessage());
	        BaseApiResponse baseApiResponse = new BaseApiResponse();
	        //AppException appException = new AppException(AppConstants.ErrorTypes.INVALID_TOKEN_ERROR, AppConstants.ErrorCodes.INVALID_TOKEN_ERROR_CODE,AppConstants.ErrorMessages.INVALID_TOKEN_ERROR_MESSAGE);
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(tokenNotValidException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @RequestLogger
	    @ExceptionHandler(FileStorageException.class)
	    public ResponseEntity<BaseApiResponse> fileStorageException(
	            FileStorageException fileStorageException, HttpServletRequest request) {
	    	logger.error(fileStorageException.getMessage());
	        BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(fileStorageException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(UserNotFoundException.class)
	    public ResponseEntity<BaseApiResponse> userNotFoundException(UserNotFoundException userNotFoundException, HttpServletRequest request) {
	    	logger.error(userNotFoundException.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(userNotFoundException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(InvalidInputException.class)
	    public ResponseEntity<BaseApiResponse> invalidInputException(InvalidInputException invalidFileException, HttpServletRequest request) {
	    	logger.error(invalidFileException.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(invalidFileException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(UserDetailsNotFoundException.class)
	    public ResponseEntity<BaseApiResponse> userDetailsNotFoundException(UserDetailsNotFoundException userDetailsNotFoundException, HttpServletRequest request) {
	    	logger.error(userDetailsNotFoundException.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(userDetailsNotFoundException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(NoSkillFoundException.class)
	    public ResponseEntity<BaseApiResponse> otpNotMatchException(NoSkillFoundException noSkillFoundException, HttpServletRequest request) {
	    	logger.error(noSkillFoundException.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(noSkillFoundException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	  
	    @ExceptionHandler(AmazonClientException.class)
	    public ResponseEntity<BaseApiResponse> amazonClientException(AmazonClientException amazonClientException, HttpServletRequest request) {
	    	logger.error(amazonClientException.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(amazonClientException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(AmazonS3Exception.class)
	    public ResponseEntity<BaseApiResponse> amazonS3Exception(AmazonS3Exception amazonS3Exception) {
	    	logger.error(amazonS3Exception.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(amazonS3Exception);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(TokenNotValidException.class)
	    public ResponseEntity<BaseApiResponse> handleInvalidTokenException(TokenNotValidException tokenNotValid, HttpServletRequest request) {
	    	logger.error(tokenNotValid.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(tokenNotValid);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(UnableToSendEmailException.class)
	    public ResponseEntity<BaseApiResponse> unableToSendEmailException(UnableToSendEmailException unableToSendEmailException, HttpServletRequest request) {
	    	logger.error(unableToSendEmailException.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(unableToSendEmailException);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }


	    @ExceptionHandler(TokenAlreadyVerifiedException.class)
	    public ResponseEntity<BaseApiResponse> tokenAlreadyVerifiedException(TokenAlreadyVerifiedException exception, HttpServletRequest request) {
	    	logger.error(exception.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(exception);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

	    @ExceptionHandler(AppUpGradationException.class)
	    public ResponseEntity<BaseApiResponse> appUpGradationException(AppUpGradationException exception, HttpServletRequest request) {
	    	logger.error(exception.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(exception);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }
	    @ExceptionHandler(value = {InvalidFormatException.class})
	    public ResponseEntity<BaseApiResponse> handleIllegalArgumentException(InvalidFormatException exception) {
	    	logger.error(exception.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(exception);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }
	    
	    @ExceptionHandler(value = {CountryNotFoundException.class})
	    public ResponseEntity<BaseApiResponse> countryNotFoundException(CountryNotFoundException exception) {
	    	logger.error(exception.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(exception);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }
	    
	    @ExceptionHandler(value = {MasterStateNotFoundException.class})
	    public ResponseEntity<BaseApiResponse> masterStateNotFoundException(MasterStateNotFoundException exception) {
	    	logger.error(exception.getMessage());
	    	BaseApiResponse baseApiResponse = new BaseApiResponse();
	        baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
	        baseApiResponse.setResponseData(exception);
	        return new ResponseEntity<BaseApiResponse>(baseApiResponse, HttpStatus.OK);
	    }

}
