package com.innovationm.igotgame.aspect;

import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingRequestWrapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovationm.igotgame.annotation.RequestLogger;
import com.innovationm.igotgame.bo.RequestResponseLogBo;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.service.RequestResponseLogService;

@Aspect
@Component
public class RequestLoggerAspect {

    private final Logger logger = LogManager.getLogger(this.getClass());

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    RequestResponseLogService requestResponseLogService;


    @Around("execution(@com.innovationm.igotgame.annotation.RequestLogger * *.*(..)) && @annotation(requestLogger)")
    public Object logRequestForException(ProceedingJoinPoint joinPoint, RequestLogger requestLogger)
            throws Throwable {

        Object retVal = null;
        String requestUrl = "";
        String requestHeader = "";
        String requestBody = "";
        String requestMethod = "";
        String apiName = "";
        String responseBody = "";
        String responseStatus = "";
        RequestResponseLogBo requestResponseLogBo = null;

        /** Caching request for logging **/
        ContentCachingRequestWrapper request = getWrapper(joinPoint);

        /** fetching values from cached request **/
        if(request!=null)
        { requestUrl = request.getRequestURL().toString();
        StringBuilder headerValue = new StringBuilder();
        for (String header : Collections.list(request.getHeaderNames())) {
            headerValue.append(header).append(":").append(request.getHeader(header)).append("\n");
        }
        requestHeader = headerValue.toString();
        requestMethod = request.getMethod();

        requestBody = getRequestBody(request);
        String arr[] = requestUrl.split("/");
        apiName = arr[arr.length - 2] + "/" + arr[arr.length - 1];}
        Date beforeExecution = new Date();


        /******* The following code will be executed after the target method execution ********/


        retVal = joinPoint.proceed();
        
        /** Calculating Execution Time **/
        Date afterExecution = new Date();
        long executionTimeInMilliSeconds = afterExecution.getTime() - beforeExecution.getTime();
        double executionTimeinSeconds = executionTimeInMilliSeconds / 1000.0d;
        
        /** Fetching ResponseEntity from response **/
        @SuppressWarnings("unchecked")
        ResponseEntity<BaseApiResponse> response = (ResponseEntity<BaseApiResponse>) retVal;
        responseStatus = response.getStatusCode().name();
        BaseApiResponse baseApiResponse = response.getBody();
        responseBody = objectMapper.writeValueAsString(baseApiResponse);

        /** Creating RequestResponseLogBo Object and setting values to it **/
        requestResponseLogBo = new RequestResponseLogBo();
        requestResponseLogBo.setApiName(apiName);
        requestResponseLogBo.setRequestHeaders(requestHeader);
        requestResponseLogBo.setRequestHttpMethod(requestMethod);
        requestResponseLogBo.setRequestString(requestBody);
        requestResponseLogBo.setRequestUrl(requestUrl);
        requestResponseLogBo.setResponseString(responseBody);
        requestResponseLogBo.setResponseStatus(responseStatus);
        requestResponseLogBo.setResponseTime(executionTimeinSeconds);

        /** Calling RequestResponseLogService to log the request and response **/
        requestResponseLogService.logRequestResponse(requestResponseLogBo);

        return retVal;

    }

    private String getRequestBody(final ContentCachingRequestWrapper wrapper) {

        String payload = null;
        if (wrapper != null) {
            byte[] buf = wrapper.getContentAsByteArray();
            if (buf.length > 0) {
                try {
                    int maxLength = buf.length > 500 ? 500 : buf.length;
                    payload = new String(buf, 0, maxLength, wrapper.getCharacterEncoding());
                } catch (UnsupportedEncodingException e) {
                    logger.error("UnsupportedEncoding.", e);
                }
            }
        }
        return payload;

    }

    private ContentCachingRequestWrapper getWrapper(ProceedingJoinPoint joinPoint) {


        Object[] args = joinPoint.getArgs();
        ContentCachingRequestWrapper request = null;

        for (Object arg : args) {
            if (arg instanceof ContentCachingRequestWrapper) {

                request = (ContentCachingRequestWrapper) arg;
                break;
            }
        }

        return request;
    }


    /**************************EXTRA********************************************/



    /*
     * // @Around("execution(@com.assessmentAggregator.api.annotation.RequestLogger * *.*(..)) && @annotation(requestLogger)"
     * )
     *
     * @Around("execution(* (@com.assessmentAggregator.api.annotation.RequestLogger *).*(..))   &&  @within(requestLogger) "
     * ) public Object logRequest(ProceedingJoinPoint joinPoint, RequestLogger
     * requestLogger) throws Throwable {
     *
     *
     * Object retVal = null; String requestUrl = ""; String requestHeader = "";
     * String requestBody = ""; String requestMethod = ""; String apiName = "";
     * String responseBody = ""; String responseStatus = ""; RequestResponseLogBo
     * requestResponseLogBo = null;
     *
     *
     *
     *//** Caching request for logging **/
    /*
     * ContentCachingRequestWrapper request = getWrapper(joinPoint);
     *
     *
     *
     *
     *//** fetching values from cached request **/
    /*
     * requestUrl = request.getRequestURL().toString(); StringBuilder headerValue =
     * new StringBuilder(); for (String header :
     * Collections.list(request.getHeaderNames())) {
     * headerValue.append(header).append(":").append(request.getHeader(header)).
     * append("\n"); } requestHeader = headerValue.toString(); requestMethod =
     * request.getMethod();
     *
     * requestBody = getRequestBody(request); String arr[] = requestUrl.split("/");
     * apiName = arr[arr.length-2]+"/"+arr[arr.length-1]; Date beforeExecution = new
     * Date();
     *
     *
     *
     *//******
     * The following code will be executed after the target method execution
     ********/
    /*
     * retVal = joinPoint.proceed();
     *
     *//** Calculating Execution Time **/
    /*
     * Date afterExecution = new Date(); long executionTimeInMilliSeconds =
     * afterExecution.getTime() - beforeExecution.getTime(); double
     * executionTimeinSeconds = executionTimeInMilliSeconds/1000.0d ;
     *
     *
     *//** Fetching ResponseEntity from response **/
    /*
     * @SuppressWarnings("unchecked") ResponseEntity<BaseApiResponse> response =
     * (ResponseEntity<BaseApiResponse>)retVal; responseStatus =
     * response.getStatusCode().name(); BaseApiResponse baseApiResponse =
     * response.getBody(); responseBody =
     * objectMapper.writeValueAsString(baseApiResponse);
     *
     *
     *
     *
     *//** Creating RequestResponseLogBo Object and setting values to it **/

    /*
     * requestResponseLogBo = new RequestResponseLogBo();
     * requestResponseLogBo.setApiName(apiName);
     * requestResponseLogBo.setRequestHeaders(requestHeader);
     * requestResponseLogBo.setRequestHttpMethod(requestMethod);
     * requestResponseLogBo.setRequestString(requestBody);
     * requestResponseLogBo.setRequestUrl(requestUrl);
     * requestResponseLogBo.setResponseContentLength(responseBody.length());
     * requestResponseLogBo.setResponseString(responseBody);
     * requestResponseLogBo.setResponseStatus(responseStatus);
     * requestResponseLogBo.setResponseTime(executionTimeinSeconds);
     *
     *//** Calling RequestResponseLogService to log the request and response **//*
     * requestResponseLogService.
     * logRequestResponse(
     * requestResponseLogBo);
     *
     *
     * return retVal;
     *
     * }
     */

}
