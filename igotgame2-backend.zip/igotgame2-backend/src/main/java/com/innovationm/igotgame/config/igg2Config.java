package com.innovationm.igotgame.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

@Configuration
public class igg2Config {

	@Value("${aws.s3.accessKeyId}")
	private String accessKeyId;
	
	@Value("${aws.s3.secretAccessKey}")
	private String secretAccessKey;
	
	@Value("${aws.s3.regions}")
	private String awsRegions;
	
	
	@Bean
	public AmazonS3 getS3()
	{
	 //System.out.println(accessKeyId+"'''''''"+secretAccessKey);
 		 AmazonS3 amazonS3 =AmazonS3ClientBuilder.standard().withCredentials
 				(new AWSStaticCredentialsProvider
						(new BasicAWSCredentials(accessKeyId, secretAccessKey))
						).withRegion(awsRegions).build();
 		 return amazonS3;
	}
}
