package com.innovationm.igotgame.constant;

public interface AppConstants {

	interface StatusCodes {
		int SUCCESS = 0;
		int FAILURE = 1;
	}

	interface Commons {

		String BLANK_STRING_VALUE = "";
		String ROLE_ORGANIZATION="ORGANIZATION";
		String ROLE_RECRUITER="RECRUITER";
		String ROLE_CANDIDATE="CANDIDATE";
		String SLASH = "/";

	}

	public interface PropertiesFileConfiguration {
		// String APPLICATION_PROPERTIES_SOURCE_PATH="classpath:application.properties";
		String APPLICATION_PROPERTIES_SOURCE_PATH = "file:///mnt/onboarding/properties/";
	}

	interface ErrorType {

		String INVALID_TOKEN_ERROR_TYPE = "Invalid Token ";
		String ENTITY_NOT_EXISTS_ERROR = "Entity Not Exists";
		String INVALID_ROLE = "Invalid role";
		String VERIFICATION_TOKEN_ALREADY_VERIFIED = "Verification Token Already Verified";
		String INVLAID_VERIFICATION_LINK_ERROR = "Invalid verification Link";
		String PATH_NULL_FOR_FILE = "Null Path Error";
		String UPLOAD_FILE_EXCEPTION = "Upload File Exception";
		String DOMAIN_DOES_NOT_MATCH_ERROR="Domain Does not match";
		String BAD_REQUEST_ERROR="Bad Request";
		String INVLAID_EMAIL="Invalid email"; 
		String INVALID_INPUT_ERROR = "Invalid Input";
		String SIGN_IN_ERROR ="Login Error";
		String SIGN_UP_ERROR = "Signup Error";
		String EMAIL_ERROR = "Error Sending Invite";
		String MASTER_COUNTRY_EXIST_ERROR = "Does Not Exist";
		String MASTER_STATE_EXIST_ERROR = "Does Not Exist";
	}

	interface ErrorCodes {

		String INVALID_TOKEN_ERROR_CODE = "104";
		String ENTITY_NOT_EXISTS_ERROR_CODE = "102";
		String INVALID_ROLE_ERROR_CODE = "103";
		String VERIFICATION_TOKEN_ALREADY_VERIFIED = "167";
		String INVALID_VERIFICATION_LINK_CODE = "150";
		String PATH_NULL_FOR_FILE_ERROR_CODE = "111";
		String UPLOAD_FILE_EXCEPTION_CODE = "112";
		String BAD_REQUEST_CODE="115";
		String DOMAIN_DOES_NOT_MATCH_ERROR_CODE="113";
		String INVLAID_EMAIL_CODE="116";
		String INVALID_INPUT_ERROR_CODE = "105";
		String USER_DOES_NOT_EXISTS_ERROR_CODE = "106";
		String USER_NOT_VERIFIED_ERROR_CODE = "107";
		String INVALID_CREDENTIALS_ERROR_CODE = "108";
		String USER_ALREADY_EXISTS_ERROR_CODE = "109";
		String EMAIL_ERROR_CODE = "110";
		String MASTER_COUNTRY_ERROR_CODE = "115";
		String MASTER_STATE_ERROR_CODE = "116";
		
	}

	interface ErrorMessage {

		String INVALID_TOKEN_ERROR_MESSAGE = "Invalid  Security Token - Authorization";
		String ENTITY_NOT_EXISTS_ERROR_MESSAGE = "Entity Not Exists";
		String USER_DOES_NOT_EXIST = "Account does not Exist";
		String ID_TOKEN_MISMATCH = "Google id token mismatched ";
		String USER_NOT_VERIFIED = "User not verified";
		String INVALID_ROLE_ERROR_MESSAGE = "Role is Invalid!";
		String VERIFICATION_TOKEN_ENTITY_NOT_PRESENT = "Invalid Verification Link";
		String VERIFICATION_TOKEN_ALREADY_VERIFIED = "Your account is already activated. Now you can login to the application.";
		String INVALID_VERIFICATION_LINK_ERROR_MESSAGE = "Verification Link is expired";
		String EMAIL_ID_NOT_VERIFIED_ERROR_MESSAGE = "Email ID is not verified, please verify Email ID";
		String OPPORTUNITY_NOT_EXISTS="Opportunity with given Id does not exist in database";
		String RECRUITER_NOT_EXISTS="Recruiter with given Id does not exist in database";
		String STUDENT_NOT_EXISTS="Student with given Id does not exist in database";
		String ORGANISATION_NOT_EXISTS="Organisation with given Id does not exist in database";	
		String PATH_NULL_FOR_FILE_ERROR_MESSAGE = "File Path provided for generating Pre sigend URL is null";
		String DOMAIN_DOES_NOT_MATCH="Recruiter email domain does not match with Organisation domain";
		String BAD_REQUEST_MESSAGE="It is a bad request.";
		String INVLAID_EMAIL_MESSAGE="Please provide a valid email";
		String INVALID_FILTER_VALUE="FilterValue can only be 'ACTIVE','INACTIVE', or 'ALL'";
		String INVALID_RECRUITER_STATUS="Recruiter status can only be 'ACTIVE' or 'INACTIVE'";
		String USER_DOES_NOT_EXISTS_ERROR_MESSAGE = "Please enter a registered account";
		String USER_NOT_VERIFIED_ERROR_MESSAGE = "Email ID is not verified, please verify Email ID first";
		String INVALID_CREDENTIALS_ERROR_MESSAGE = "Email ID and Password did not match";
		String USER_ALREADY_EXISTS_ERROR_MESSAGE = "User already registered. Try with  different Email ID.";
		String EMAIL_ERROR_MESSAGE = "Invite is not sent successfully. Please try again";
		String INVALID_CONTACT_NO="Please provide valid contact no";
		String INVALID_CATEGORY_NO="provided Category or subcategory doesn't exist in database";
		String ALREADY_ADDED_SKILL="Details for this skill are alread added by you.";
		String INVALID_FILE_FORMAT="File you are uploading is not an image.";
		String MASTER_COUNTRY_NOT_EXTIS_MESSAGE = "Country Does Not Exist";
		String MASTER_STATE_NOT_EXTIS_MESSAGE = "STATES Does Not Exist";

	}

	interface AppSecurity {

		String APP_SECURITY_TOKEN_NOT_PROVIDED = "App Security Token not provided.";
		String TIME_STAMP_NOT_PROVIDED = "Timestamp not provided.";
		String APP_SECURITY_TOKEN_DIDNOT_MATCH = "App Security Token Did NOT match.";
		String TIMESTAMP = "timestamp";

	}

	interface Common {

		String BLANK_STRING_VALUE = "";
		String VERIFICATION_FOR_SIGNUP = "emailVerificationLink";
		String TOKEN = "token";
		String TOKEN_HEADER = "Authorization";
	}

	public interface Config {
		
		String APPLICATION_PROPERTY_SOURCE_PATH = "file:///C:/Users/jaisw/Desktop/igg2/igotgame2-backend/src/main/resources/application.properties";
				
		//String APPLICATION_PROPERTY_SOURCE_PATH = "file:///mnt/igg/properties/application.properties";
		//String APPLICATION_PROPERTY_SOURCE_PATH = "file:///C:/gg2/igg2Main/igotgame2-backend/src/main/resources/application.properties";
		//String APPLICATION_PROPERTY_SOURCE_PATH = "file:///D:/IGG2/igotgame2-backend/src/main/resources/application.properties";
	}
	
	interface MailConstant {
		String BLANK_STRING_VALUE = "";
		String SIGNUP = "signup";
		String RECRUITER_CREATED="Recruiter Created";
	}

	public interface CandidateHomePage{
		
		final Long NAME=10l;
		final Long PROFILE=20l;
		final Long DOB=10l;
		final Long GENDER=10l;
		final Long CONTACT=10l;
		final Long ADDRESS=10l;
		final Long ABOUT=10l;
		final Long SKILL=20l;
		

		
		
		
	}
	
}
