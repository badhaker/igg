package com.innovationm.igotgame.constant;

public interface RestMappingConstants {

	String APP_BASE = "/api/v1";
	String STUDENT_SIGNUP = APP_BASE+"/studentSignUp";
	String ORGANISATION_SIGNUP = APP_BASE+"/organisationSignUp";
	String VERIFY_EMAIL = APP_BASE+"/verifyEmail";
	String SIGNIN = APP_BASE+"/signIn";
	String GENERATE_PASSWORD_RESET_TOKEN = "/generatePasswordResetToken";
	String GET_COMMON_DETAILS=APP_BASE+"/GET_COMMON_DETAILS";
	
	
	public interface Recruiter{
		String REC_BASE_URI="/recruiter";
		String CREATE_RECRUITER=REC_BASE_URI+"/create";
		String UPDATE_PROFILE=REC_BASE_URI+"/updateProfile";
		String UPDATE_PROFILE_STATUS=REC_BASE_URI+"/updateProfileStatus";
		String GET_PROFILE_DETAILS=REC_BASE_URI+"/getProfileDetails";
		String GET_RECRUITER_LIST_BY_ORGANISATION=REC_BASE_URI+"/getRecruiterList";
		String DELETE_RECRUITER=REC_BASE_URI+"/deleteProfile";
	}
	
	public interface Organisation{
		String ORGANISATION_BASE_URI="/organisation";
		String GET_PROFILE_DETAILS=ORGANISATION_BASE_URI+"/getProfileDetails";
		String UPDATE_PROFILE=ORGANISATION_BASE_URI+"/updateProfile";
		String GET_ORGANISATION_DASHBOARD_URI=ORGANISATION_BASE_URI+"/GetOrganisationDashboard";

	}
	public interface Candidate{
		String CANDIDATE_BASE_URI="/candidate";
		String GET_PROFILE_DETAILS=CANDIDATE_BASE_URI+"/getProfileDetails";
		String UPDATE_PROFILE=CANDIDATE_BASE_URI+"/updateProfile";
		String APPLY_ON_OPPORTUNITY_URI=CANDIDATE_BASE_URI+"/applyOnOpportunity";
		String ADD_SKILL_URI=CANDIDATE_BASE_URI+"/addSkill";
		String GET_SKILLS_DETAILS=CANDIDATE_BASE_URI+"/getSkills";
		String DELETE_FILE=CANDIDATE_BASE_URI+"/deleteSkillFile";
		String GET_HOMEPAGE=CANDIDATE_BASE_URI+"/getHomePage";
	}
	
	public interface Category
	{
		String GET_MAIN_CATEGORY_LIST="/getMainCategoryList";
		String GET_SUB_CATEGORY_LIST_BY_MAIN_CATEGORY="/getSubCategoryList/{mainCategoryId}";
		

	}	
	
	public interface MasterCountryInterfaceUri {
		static final String MASTER_COUNTRY_BASE_URI = "/master";
		static final String MASTER_COUNTRYS_GET_URI = "/getCountryList";
		static final String MASTER_STATE_GET_URI = "/getStateListId";
		static final String MASTER_CITY_GET_URI = "/getCityListId";
	}
}
