package com.innovationm.igotgame.constant;

public interface SecurityConstants {
	
	public interface SecretKey {
		String SECRET = "SecretKeyToGenJWTs";
		String TOKEN_PREFIX = "Bearer ";
		String TOKEN_HEADER = "Authorization";
		
	}

	String APP_AUTHENITICATION_TOKEN = "AppAuthenticationToken";
	String APP_SECURITY_KEY = "#igotgame2@innovationm.com$k1";
}
