package com.innovationm.igotgame.controller;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.constant.RestMappingConstants;
import com.innovationm.igotgame.exception.BadRequestException;
import com.innovationm.igotgame.request.CandidateProfileRequest;
import com.innovationm.igotgame.request.CandidateSkillDetailRequest;
import com.innovationm.igotgame.request.RecruiterProfileRequest;
import com.innovationm.igotgame.response.AcceptedStudentsListResponse;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetCandidateHomePageResponse;
import com.innovationm.igotgame.response.GetCandidateProfileDetailResponse;
import com.innovationm.igotgame.response.GetCandidateSkillsResponse;
import com.innovationm.igotgame.response.GetOrganisationProfileDetailResponse;
import com.innovationm.igotgame.response.StudentListResponse;
import com.innovationm.igotgame.service.CandidateService;

@RestController
@RequestMapping(RestMappingConstants.APP_BASE)
public class CandidateController {
	private final Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	private CandidateService candidateService;

	/*
	 * @PostMapping(RestMappingConstants.Candidate.APPLY_ON_OPPORTUNITY_URI) public
	 * ResponseEntity<BaseApiResponse<CommonSuccessResponse>>
	 * applyOnOpportunity(@RequestParam Long candidateAccountId, @RequestParam Long
	 * opportunityId) { logger.info("@@@@@ inside apply on opportunity api @@@@@@");
	 * CommonSuccessResponse
	 * commonSuccessResponse=candidateService.applyOnOpportunity(candidateAccountId,
	 * opportunityId); BaseApiResponse<CommonSuccessResponse> baseApiResponse=new
	 * BaseApiResponse<>(commonSuccessResponse); return new
	 * ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse,
	 * HttpStatus.CREATED);
	 * 
	 * }
	 */
	
	@PutMapping(RestMappingConstants.Candidate.UPDATE_PROFILE)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> updateStudentProfile(
			@RequestPart String jsonRequest,
			@RequestPart MultipartFile profileImage,
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) throws IOException 
	{
		logger.info("@@@@@ inside update candidate profile api @@@@@@");
		//CandidateProfileRequest request = new ObjectMapper().readValue(jsonRequest, CandidateProfileRequest.class); ""change kiye hai""
		CandidateProfileRequest request = null;
		try {
			 request= new ObjectMapper().readValue(jsonRequest, CandidateProfileRequest.class);
		}
		catch(Exception e)
		{
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
					AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE); 
		}
		
		CommonSuccessResponse commonSuccessResponse = candidateService.updateCandidateProfile(request, profileImage,
				token);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);
	}

	@PostMapping(RestMappingConstants.Candidate.ADD_SKILL_URI)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> addSkill(
			// @RequestBody CandidateSkillDetailRequest request,
			@RequestPart String jsonRequest, @RequestPart MultipartFile[] media,
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) throws IOException {
		logger.info("@@@@@ inside add skill api @@@@@@");
		CandidateSkillDetailRequest request = new ObjectMapper().readValue(jsonRequest,
				CandidateSkillDetailRequest.class);
		CommonSuccessResponse commonSuccessResponse = candidateService.addSkill(request, token, media);

		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);
	}

	@GetMapping(RestMappingConstants.Candidate.GET_PROFILE_DETAILS)
	public ResponseEntity<BaseApiResponse<GetCandidateProfileDetailResponse>> getCandidateProfileDetail(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) {
		logger.info("@@@@@ inside get candidate profile details api @@@@@@");
		GetCandidateProfileDetailResponse commonSuccessResponse = candidateService.getCandidateProfile(token);
		BaseApiResponse<GetCandidateProfileDetailResponse> baseApiResponse = new BaseApiResponse<>(
				commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<GetCandidateProfileDetailResponse>>(baseApiResponse, HttpStatus.OK);
	}

	@GetMapping(RestMappingConstants.Candidate.GET_SKILLS_DETAILS)
	public ResponseEntity<BaseApiResponse<List<GetCandidateSkillsResponse>>> getCandidateSkills(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) {
		logger.info("@@@@@ inside get candidate Skill details api @@@@@@");
		List<GetCandidateSkillsResponse> commonSuccessResponse = candidateService.getCandidateSkills(token); // ask
		BaseApiResponse<List<GetCandidateSkillsResponse>> baseApiResponse = new BaseApiResponse<>(
				commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<List<GetCandidateSkillsResponse>>>(baseApiResponse, HttpStatus.OK);
	}

	@GetMapping(RestMappingConstants.Candidate.GET_HOMEPAGE)
	public ResponseEntity<BaseApiResponse<GetCandidateHomePageResponse>> getCandidateHomePage(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) {
		logger.info("@@@@@ inside get candidate homepage api @@@@@@");
		GetCandidateHomePageResponse commonSuccessResponse = candidateService.getCandidateHomePage(token);
		BaseApiResponse<GetCandidateHomePageResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<GetCandidateHomePageResponse>>(baseApiResponse, HttpStatus.OK);
	}

	// -->StudentListResponse ka bna rhe hai<--
	@GetMapping("/getstudentList/{opportunityId}") // add kro
	public ResponseEntity<BaseApiResponse<List<StudentListResponse>>> getStudentList( // add kro
			@PathVariable Long opportunityId) {
		List<StudentListResponse> profile = candidateService.getStudentList(opportunityId);
		BaseApiResponse<List<StudentListResponse>> baseApiResponse = new BaseApiResponse<>(profile);
		return new ResponseEntity<BaseApiResponse<List<StudentListResponse>>>(baseApiResponse, HttpStatus.OK);

	}

	// -->AcceptedStudentsListResponse ka bna rhe hai<--
	@GetMapping("/getAcceptedStudentList/{opportunityId}") // add kro
	public ResponseEntity<BaseApiResponse<List<AcceptedStudentsListResponse>>> getAcceptedStudentList( // add kro
			@PathVariable Long opportunityId) {
		List<AcceptedStudentsListResponse> profile = candidateService.getAcceptedStudentList(opportunityId);
		BaseApiResponse<List<AcceptedStudentsListResponse>> baseApiResponse = new BaseApiResponse<>(profile);
		return new ResponseEntity<BaseApiResponse<List<AcceptedStudentsListResponse>>>(baseApiResponse, HttpStatus.OK);

	}

}
