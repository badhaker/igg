package com.innovationm.igotgame.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.igotgame.constant.RestMappingConstants;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.response.MasterCityResponse;
import com.innovationm.igotgame.response.MasterCountryResponse;
import com.innovationm.igotgame.response.MasterStateResponse;
import com.innovationm.igotgame.service.impl.LocationServiceImpl;

@RestController
@RequestMapping(path = RestMappingConstants.MasterCountryInterfaceUri.MASTER_COUNTRY_BASE_URI)
public class LocationController {

	@Autowired
	LocationServiceImpl locationServiceImpl;

	@GetMapping(RestMappingConstants.MasterCountryInterfaceUri.MASTER_COUNTRYS_GET_URI)
	public ResponseEntity<?> getAllCountry() {

		List<MasterCountryResponse> masterCountryResponse = locationServiceImpl.getAllCountry();

		BaseApiResponse<List<MasterCountryResponse>> baseApiResponse = new BaseApiResponse<>(masterCountryResponse);
		return new ResponseEntity<BaseApiResponse<List<MasterCountryResponse>>>(baseApiResponse, HttpStatus.OK);

	}
	
	@GetMapping(RestMappingConstants.MasterCountryInterfaceUri.MASTER_STATE_GET_URI + "/{id}")
	public ResponseEntity<?> getMasterCountryById(@PathVariable("id") int id) {

		List<MasterStateResponse> masterStateResponse = locationServiceImpl.getAllStatesByCountryId(id);
		
		BaseApiResponse<List<MasterStateResponse>> baseApiResponse = new BaseApiResponse<>(masterStateResponse);
		return new ResponseEntity<BaseApiResponse<List<MasterStateResponse>>>(baseApiResponse, HttpStatus.OK);

	}
	@GetMapping(RestMappingConstants.MasterCountryInterfaceUri.MASTER_CITY_GET_URI + "/{id}")
	public ResponseEntity<?> getAllCityByStateId(@PathVariable("id") int id) {
		
			List<MasterCityResponse> masterCityResponse = locationServiceImpl.getAllCityByStateId(id);
			
			BaseApiResponse<List<MasterCityResponse>> baseApiResponse = new BaseApiResponse<>(masterCityResponse);
	      return new ResponseEntity<BaseApiResponse<List<MasterCityResponse>>>(baseApiResponse, HttpStatus.OK);
         }
}
