package com.innovationm.igotgame.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.igotgame.constant.RestMappingConstants;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.response.MainCategoryListResponse;
import com.innovationm.igotgame.service.MainCategoryService;

@RestController
@RequestMapping(RestMappingConstants.APP_BASE)
public class MainCategoryController {
	private final Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	private MainCategoryService mainCategoryService;
	
	@GetMapping(RestMappingConstants.Category.GET_MAIN_CATEGORY_LIST)
	public ResponseEntity<BaseApiResponse<List<MainCategoryListResponse>>> getMainCategoryList()
	{
		logger.info("@@@@@ inside get main category list api @@@@@@");

		List<MainCategoryListResponse> opportunityDetail=mainCategoryService.getMainCategoryList();
		BaseApiResponse<List<MainCategoryListResponse>> baseApiResponse=new BaseApiResponse<>(opportunityDetail);
		return new ResponseEntity<BaseApiResponse<List<MainCategoryListResponse>>>(baseApiResponse, HttpStatus.OK);	
	}

}
