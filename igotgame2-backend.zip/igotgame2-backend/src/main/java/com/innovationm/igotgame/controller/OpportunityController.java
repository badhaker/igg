package com.innovationm.igotgame.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovationm.igotgame.Enum.OpportunityStatus;
import com.innovationm.igotgame.request.CreateOpportunityRequest;
import com.innovationm.igotgame.request.RecruiterProfileRequest;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.response.CandidateOpportunityListResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetOpportunityDetailResponse;
import com.innovationm.igotgame.response.RecruiterOpportunityListResponse;
import com.innovationm.igotgame.security.JwtTokenProvider;
import com.innovationm.igotgame.service.OpportunityService;
import com.innovationm.igotgame.constant.SecurityConstants;

@RestController
@RequestMapping("/opportunity")
public class OpportunityController {

	@Autowired
	private OpportunityService opportunityService;
	private final Logger logger = LogManager.getLogger(this.getClass());

	@PostMapping("/create")
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> createOpportunity(
			@RequestPart String jsonRequest, 
			@RequestPart(value= "opportunityImage",required = true) MultipartFile opportunityImage) throws IOException
	{
		logger.info("@@@@@ inside create opportunity api @@@@@@");
		CreateOpportunityRequest request= new ObjectMapper().readValue(jsonRequest, CreateOpportunityRequest.class);
		CommonSuccessResponse commonSuccessResponse=opportunityService.createOpportunity(request, opportunityImage);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse=new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.CREATED);
		
	}
	
	@GetMapping("/getDetails/{opportunityId}")
	public ResponseEntity<BaseApiResponse<GetOpportunityDetailResponse>> getOpportunityDetail(@PathVariable Long opportunityId)
	{
		GetOpportunityDetailResponse opportunityDetail=opportunityService.getOpportunityDetail(opportunityId);
		BaseApiResponse<GetOpportunityDetailResponse> baseApiResponse=new BaseApiResponse<>(opportunityDetail);
		return new ResponseEntity<BaseApiResponse<GetOpportunityDetailResponse>>(baseApiResponse, HttpStatus.OK);	
	}
	
	@DeleteMapping("/deleteOpportunity/{opportunityId}")
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> deleteOpportunity(@PathVariable Long opportunityId)
	{
		CommonSuccessResponse opportunityDetail=opportunityService.deleteOpportunity(opportunityId);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse=new BaseApiResponse<>(opportunityDetail);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);	
	}
	
	@PutMapping("/updateStatus/{opportunityId}")
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> updateStatus(@PathVariable Long opportunityId, @RequestParam OpportunityStatus status )
	{
		CommonSuccessResponse resp=opportunityService.updateStatus(opportunityId, status);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse=new BaseApiResponse<>(resp);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.CREATED);	
	}
	
	@GetMapping("/getListByRecruiterId/{recruiterAccointId}") //yeh shi hai
	public ResponseEntity<BaseApiResponse<List<RecruiterOpportunityListResponse>>> getOpportunityListByRecruiterId(@PathVariable Long recruiterAccointId)
	{
		List<RecruiterOpportunityListResponse> opportunityDetail=opportunityService.getOpportunityListByRecruiterId(recruiterAccointId);
		BaseApiResponse<List<RecruiterOpportunityListResponse>> baseApiResponse=new BaseApiResponse<>(opportunityDetail);
		return new ResponseEntity<BaseApiResponse<List<RecruiterOpportunityListResponse>>>(baseApiResponse, HttpStatus.OK);	
	}
	
	@GetMapping("/getListByCandidateId/{candidateAccountId}") //isme image wala part missing hai
	public ResponseEntity<BaseApiResponse<List<CandidateOpportunityListResponse>>> getOpportunityListByCandidateId(@PathVariable Long candidateAccountId)
	{
		List<CandidateOpportunityListResponse> opportunityDetail=opportunityService.getOpportunityListByCandidateId(candidateAccountId);
		BaseApiResponse<List<CandidateOpportunityListResponse>> baseApiResponse=new BaseApiResponse<>(opportunityDetail);
		return new ResponseEntity<BaseApiResponse<List<CandidateOpportunityListResponse>>>(baseApiResponse, HttpStatus.OK);	
	}
	
}