package com.innovationm.igotgame.controller;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.constant.RestMappingConstants;
import com.innovationm.igotgame.exception.BadRequestException;
import com.innovationm.igotgame.request.OrganisationProfileRequest;
import com.innovationm.igotgame.request.RecruiterProfileRequest;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetOrganisationDashboardResponse;
import com.innovationm.igotgame.response.GetOrganisationProfileDetailResponse;
import com.innovationm.igotgame.service.OrganisationService;

@RestController
@RequestMapping(RestMappingConstants.APP_BASE)
public class OrganisationController {
 
	private final Logger logger = LogManager.getLogger(this.getClass());
	@Autowired
	private OrganisationService organisationService;
	
	@PutMapping(RestMappingConstants.Organisation.UPDATE_PROFILE)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> upateorganisationProfile(
			@RequestPart String jsonRequest, 
			@RequestPart MultipartFile organisationImage, 
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) throws IOException
	{	
		logger.info("@@@@@ inside update organisation profile api @@@@@@");

		OrganisationProfileRequest request=null;
		try {
		request= new ObjectMapper().readValue(jsonRequest, OrganisationProfileRequest.class);
		}
		catch(Exception e)
		{
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
					AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE); 
		}
		CommonSuccessResponse commonSuccessResponse = organisationService.upateOrganisationProfile(token,request,organisationImage);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);
	}
	
	@GetMapping(RestMappingConstants.Organisation.GET_ORGANISATION_DASHBOARD_URI)
	public ResponseEntity<BaseApiResponse<GetOrganisationDashboardResponse>> getOrganisationDashboardDetail(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token)
	{
		logger.info("@@@@@ inside get organisation dashboard api @@@@@@");

		GetOrganisationDashboardResponse commonSuccessResponse = organisationService.getOrganisationDashboardDetail(token);
		BaseApiResponse<GetOrganisationDashboardResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<GetOrganisationDashboardResponse>>(baseApiResponse, HttpStatus.OK);
	}
	
	@GetMapping(RestMappingConstants.Organisation.GET_PROFILE_DETAILS)
	public ResponseEntity<BaseApiResponse<GetOrganisationProfileDetailResponse>> getOrganisationProfileDetail(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token)
	{
		logger.info("@@@@@ inside get organisation profile details api @@@@@@");
		GetOrganisationProfileDetailResponse commonSuccessResponse = organisationService.getOrganisationProfile(token);
		BaseApiResponse<GetOrganisationProfileDetailResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<GetOrganisationProfileDetailResponse>>(baseApiResponse, HttpStatus.OK);
	}
}
