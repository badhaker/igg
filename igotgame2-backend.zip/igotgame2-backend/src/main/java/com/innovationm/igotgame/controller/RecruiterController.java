package com.innovationm.igotgame.controller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovationm.igotgame.Enum.FilterRecruiterValue;
import com.innovationm.igotgame.Enum.RecruiterStatus;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.constant.RestMappingConstants;
import com.innovationm.igotgame.exception.BadRequestException;
import com.innovationm.igotgame.request.AddRecruiterRequest;
import com.innovationm.igotgame.request.OrganisationProfileRequest;
import com.innovationm.igotgame.request.RecruiterProfileRequest;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetRecruiterProfileResponse;
import com.innovationm.igotgame.response.RecruiterListResponse;
import com.innovationm.igotgame.security.JwtTokenProvider;
import com.innovationm.igotgame.service.RecruiterService;

@RestController


@RequestMapping(RestMappingConstants.APP_BASE)
public class RecruiterController {

	private final Logger logger = LogManager.getLogger(this.getClass());
	@Autowired
	private RecruiterService recruiterService;

	@PostMapping(RestMappingConstants.Recruiter.CREATE_RECRUITER)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> addRecruiter(
			@RequestBody AddRecruiterRequest request,
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) throws MessagingException, IOException 
	{
		System.out.println("inside create rec controller");
		logger.info("@@@@@ inside create recruiter api @@@@@@");
		CommonSuccessResponse commonSuccessResponse = recruiterService.addRecruiter(request,token);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.CREATED);

	}
	

	@PutMapping(RestMappingConstants.Recruiter.UPDATE_PROFILE_STATUS)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> upateRecruiterProfileStatus(
			@RequestParam RecruiterStatus status,
			@RequestParam Long recruiterAccountId)	{
		logger.info("@@@@@ inside update recruiter profile status api @@@@@@");
		CommonSuccessResponse commonSuccessResponse = recruiterService.upateRecruiterProfileStatus(status,recruiterAccountId);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);

	}
	
	@DeleteMapping(RestMappingConstants.Recruiter.DELETE_RECRUITER)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> deleteRecruiterProfile(
			@RequestParam Long recruiterAccountId)
	{
		logger.info("@@@@@ inside delete recruiter api @@@@@@");
		CommonSuccessResponse commonSuccessResponse = recruiterService.deleteRecruiterProfile(recruiterAccountId);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);
	} 
	

	@PutMapping(RestMappingConstants.Recruiter.UPDATE_PROFILE)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> upateRecruiterProfile(
			@RequestPart String jsonRequest, 
			@RequestPart(value= "profileImage",required = true) MultipartFile profileImage,
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) throws IOException
	{
		logger.info("@@@@@ inside update recruiter profile api @@@@@@");
		RecruiterProfileRequest request=null;
		try {
			 request= new ObjectMapper().readValue(jsonRequest, RecruiterProfileRequest.class);
		}
		catch(Exception e)
		{
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
					AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE); 
		}
		CommonSuccessResponse commonSuccessResponse = recruiterService.upateRecruiterProfile(token,request, profileImage);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);

	}
	
	@GetMapping(RestMappingConstants.Recruiter.GET_PROFILE_DETAILS)
	public ResponseEntity<BaseApiResponse<GetRecruiterProfileResponse>> getProfileDetails(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token) {
		logger.info("@@@@@ inside get recruiter profile details api @@@@@@");
		GetRecruiterProfileResponse profile= recruiterService.getProfileDetails(token);
		BaseApiResponse<GetRecruiterProfileResponse> baseApiResponse = new BaseApiResponse<>(profile);
		return new ResponseEntity<BaseApiResponse<GetRecruiterProfileResponse>>(baseApiResponse, HttpStatus.OK);
 
	} 
	
	@GetMapping(RestMappingConstants.Recruiter.GET_RECRUITER_LIST_BY_ORGANISATION)
	public ResponseEntity<BaseApiResponse<List<RecruiterListResponse>>> getRecruiterListByOrganisationId(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true)String token,
			@RequestParam FilterRecruiterValue filterValue) {
		logger.info("@@@@@ inside get recruiter list by organisation api @@@@@@");
		List<RecruiterListResponse> profile= recruiterService.getRecruiterListByOrganisationId(token,filterValue);
		BaseApiResponse<List<RecruiterListResponse>> baseApiResponse = new BaseApiResponse<>(profile);
		return new ResponseEntity<BaseApiResponse<List<RecruiterListResponse>>>(baseApiResponse, HttpStatus.OK);

	} 
	
	

}
