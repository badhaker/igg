package com.innovationm.igotgame.controller;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.constant.RestMappingConstants;
import com.innovationm.igotgame.constant.SecurityConstants;
import com.innovationm.igotgame.request.OrganiZationSignUpRequest;
import com.innovationm.igotgame.request.SignInRequest;
import com.innovationm.igotgame.request.StudentSignUpRequest;
import com.innovationm.igotgame.response.BaseApiResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetCommonDetailResponse;
import com.innovationm.igotgame.response.GetOrganisationProfileDetailResponse;
import com.innovationm.igotgame.response.SiginResponse;
import com.innovationm.igotgame.security.JwtTokenProvider;
import com.innovationm.igotgame.service.UserAccountService;
import com.innovationm.igotgame.service.UserProfileService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
@RestController
@CrossOrigin(origins = "*")
public class UserAuthController {

	@Autowired
	private UserAccountService userAccountService;

	@Autowired
	private UserProfileService userProfileService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	private final Logger logger = LogManager.getLogger(this.getClass());

	@PostMapping(path = RestMappingConstants.STUDENT_SIGNUP)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> studentSignUp(
			@Valid @RequestBody StudentSignUpRequest signupRequest, HttpServletResponse response, HttpServletRequest request)
			throws MessagingException, IOException {
		logger.info("@@@@@ inside student signup api @@@@@@");
		CommonSuccessResponse commonSuccessResponse = null;
		commonSuccessResponse = userAccountService.createStudent(signupRequest);
//		Authentication authentication = authenticationManager
//				.authenticate(new UsernamePasswordAuthenticationToken(signupRequest.getEmail(),signupRequest.getPassword()));
//		String jwt = jwtTokenProvider.generateToken(authentication);
//		response.setHeader("Access-Control-Expose-Headers", "Authorization");
//		response.setHeader(SecurityConstants.SecretKey.TOKEN_HEADER, SecurityConstants.SecretKey.TOKEN_PREFIX + jwt);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.CREATED);

	}

	@PostMapping(path = RestMappingConstants.ORGANISATION_SIGNUP)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> organizationSignUp (
			@RequestBody OrganiZationSignUpRequest signupRequest, HttpServletResponse response,
			HttpServletRequest request) {
		logger.info("@@@@@ inside organization signup api @@@@@@");
		CommonSuccessResponse commonSuccessResponse = null;
		commonSuccessResponse = userAccountService.createOrganisation(signupRequest);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.CREATED);

	}

	
	@GetMapping(path = RestMappingConstants.VERIFY_EMAIL)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> verifyEmail(
			@Valid @RequestParam(AppConstants.Common.TOKEN) String token, HttpServletRequest request) {
		logger.info("@@@@@ inside verifyEmail  api @@@@@@");
		CommonSuccessResponse commonSuccessResponse = null;
		commonSuccessResponse = userAccountService.verifyEmail(token);
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);

	}

	@PostMapping(path = "/test")
	public String test(@RequestHeader(SecurityConstants.SecretKey.TOKEN_HEADER) String token) {
		return "test";
	}
	
	@PostMapping(path = RestMappingConstants.SIGNIN)
	public ResponseEntity<BaseApiResponse<CommonSuccessResponse>> signIn(
			@RequestBody SignInRequest signInRequest, HttpServletResponse response,
			HttpServletRequest request){
		logger.info("@@@@@ inside signIn api @@@@@@");
		System.out.println("bad request ");
		CommonSuccessResponse commonSuccessResponse = new CommonSuccessResponse(true);
		SiginResponse signResponse = userAccountService.signIn(signInRequest);
			Authentication authentication=null;
			try {
			 authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(signInRequest.getEmail(), signInRequest.getPassword()));}
			catch(Exception e)
			{
				logger.warn(AppConstants.ErrorMessage.INVALID_CREDENTIALS_ERROR_MESSAGE);
				 throw new InternalAuthenticationServiceException(
						 AppConstants.ErrorMessage.INVALID_CREDENTIALS_ERROR_MESSAGE);
			}
			
		String jwt = jwtTokenProvider.generateToken(authentication);
		response.setHeader("Access-Control-Expose-Headers", "Authorization");
		response.setHeader(SecurityConstants.SecretKey.TOKEN_HEADER, SecurityConstants.SecretKey.TOKEN_PREFIX + jwt);
		response.setHeader("role", signResponse.getRoleName());
		BaseApiResponse<CommonSuccessResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<CommonSuccessResponse>>(baseApiResponse, HttpStatus.OK);

	}
	
	@GetMapping(RestMappingConstants.GET_COMMON_DETAILS)
	public ResponseEntity<BaseApiResponse<GetCommonDetailResponse>> getCommonDetail(
			@RequestHeader(value = AppConstants.Common.TOKEN_HEADER, required = true) String token)
	{
		logger.info("@@@@@ inside get signIn details api @@@@@@");
		GetCommonDetailResponse commonSuccessResponse = userAccountService.getCommonDetail(token);
		BaseApiResponse<GetCommonDetailResponse> baseApiResponse = new BaseApiResponse<>(commonSuccessResponse);
		return new ResponseEntity<BaseApiResponse<GetCommonDetailResponse>>(baseApiResponse, HttpStatus.OK);
	}
	
	
}
