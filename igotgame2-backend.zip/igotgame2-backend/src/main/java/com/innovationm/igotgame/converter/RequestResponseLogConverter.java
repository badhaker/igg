package com.innovationm.igotgame.converter;

import org.springframework.beans.BeanUtils;

import com.innovationm.igotgame.bo.RequestResponseLogBo;
import com.innovationm.igotgame.entity.RequestResponseLogEntity;

public class RequestResponseLogConverter {

	public static  RequestResponseLogEntity convertRequestResponseLogBoToRequestResponseLogEntity (RequestResponseLogBo requestResponseLogBo)
	{
		RequestResponseLogEntity requestResponseLogEntity = new RequestResponseLogEntity();
		BeanUtils.copyProperties(requestResponseLogBo, requestResponseLogEntity);
		return requestResponseLogEntity;
	}
		
	                                                        
}
