package com.innovationm.igotgame.dao.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.innovationm.igotgame.dao.RequestResponseLogDao;
import com.innovationm.igotgame.entity.RequestResponseLogEntity;
import com.innovationm.igotgame.repository.RequestResponseLogRepository;

@Component
public class RequestResponseLogDaoImpl implements RequestResponseLogDao {

	@Autowired
	RequestResponseLogRepository requestResponseLogRepository;
	
	@Override
	public void saveRequestResponseLog(RequestResponseLogEntity requestResponseLogEntity) {
		
		requestResponseLogRepository.save(requestResponseLogEntity);
	}
	

}
