package com.innovationm.igotgame.dao;

import com.innovationm.igotgame.entity.RequestResponseLogEntity;

public interface RequestResponseLogDao {

	public void saveRequestResponseLog(RequestResponseLogEntity requestResponseLogEntity);

}
