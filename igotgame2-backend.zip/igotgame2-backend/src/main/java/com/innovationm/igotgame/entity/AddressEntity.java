package com.innovationm.igotgame.entity;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.sun.istack.NotNull;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@Setter
@Getter
public class AddressEntity extends BaseEntity {
	@Column(name = "address_line1", nullable = true, columnDefinition = "TEXT")
	String addressLine1;

//	String addressLine2;
	@Column(name = "city", nullable = true)
	private String city;
	@Column(name = "state", nullable = true)
	private String state;
	@Column(name = "country", nullable = true)
	private String country;
//	@NotNull
	@Column(name = "pin_code")
	private String pinCode;

}
