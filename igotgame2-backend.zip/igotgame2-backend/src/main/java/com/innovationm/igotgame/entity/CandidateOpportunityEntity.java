package com.innovationm.igotgame.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "candidate_opportunity")
@Setter
@Getter
@Builder
@ToString
public class CandidateOpportunityEntity extends BaseEntity {
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
	@JoinColumn(name = "user_profile_id")
	private UserProfileEntity userProfileId;
	
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY ,cascade = CascadeType.ALL)
	@JoinColumn(name = "opportunity_id")
	private OpportunityEntity opportunity;
	
	@Column(name="request_accepted",nullable=false,columnDefinition="boolean default false ")
	private boolean requestAccepted;
	
	@Column(name="opportunity_image_path")
	private String opportunityImagePath;  //I have added this

}
