package com.innovationm.igotgame.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "candidate_skills")
@Setter
@Getter  
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CandidateSkillsEntity extends BaseEntity {
	
	@Column(name="description")
	private String description;
	
	@Column(name="main_catrgory_id")
	private Long mainCategoryId;
	
	@Column(name="sub_catrgory_id")
	private Long subCategoryId;
	
	@JoinColumn(name = "candidate_profile_id")
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private UserProfileEntity userProfile;
	
	

}
