package com.innovationm.igotgame.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "candidate_subcategory")
@Setter
@Getter
@ToString
public class CandidateSubCategoryEntity extends BaseEntity {
	
	@NotNull
	@JoinColumn(name="user_profile_id")
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private UserProfileEntity userProfile;
	
	@NotNull
	@JoinColumn(name="subcategory_id")
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private MasterSubCategoryEntity  subCategoryEntity;
	@Column(name="description")
	private String description;
	@Column(name="image")
	private String image;
}
