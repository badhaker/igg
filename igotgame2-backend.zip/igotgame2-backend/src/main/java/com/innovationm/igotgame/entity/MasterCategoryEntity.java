package com.innovationm.igotgame.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "master_category")
@Setter
@Getter
@ToString
public class MasterCategoryEntity extends BaseEntity {

	@Column(name = "name", unique = true, nullable = false)
	private String name;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "category")
	private Set<MasterSubCategoryEntity> subCategoryEntity;

}
