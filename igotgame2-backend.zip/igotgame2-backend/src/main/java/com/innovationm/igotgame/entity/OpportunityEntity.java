 package com.innovationm.igotgame.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.innovationm.igotgame.Enum.OpportunityStatus;
import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "opportunity")
@Setter
@Getter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OpportunityEntity extends AddressEntity{
	
	@Column(name="title",nullable=false)
	private String title;
	
	
	@Column(name="about",nullable=false,columnDefinition="TEXT")
	private String about;
	
	@Column(name="opportunity_image_path")
	private String opportunityImagePath;
	
	@Column(name="our_wins",nullable=false,columnDefinition="TEXT")
	private String ourWins;

	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "subcategory_id")
	private MasterSubCategoryEntity  subCategoryEntity;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "category_id")
	
	private MasterCategoryEntity  categoryEntity;
	@Column(name="view_count")
	private int viewCount;
	
	@Column(name="status",nullable = false,updatable = true, columnDefinition = "enum('OPEN','AWARDED','CLOSED') default 'OPEN' ")
	@Enumerated(EnumType.STRING)
	private OpportunityStatus status;
	
	//@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,mappedBy="opportunity")	
	//private Set<CandidateSkillsMediaEntity>	mediaDetailsEntity;
	
	@ManyToOne (cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "recruiter_account_id" )
	private UserAccountEntity recruiterAccount;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,mappedBy="opportunity")	
	private List<OpportunityRequiredDetailsEntity> opportunityRequiredDetailsEntity;
	
	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH })
	@JoinTable(name = "candidate_opportunity", joinColumns = {
			@JoinColumn(name = "opportunity_id") }, inverseJoinColumns = { @JoinColumn(name = "user_profile_id") })
	private List<UserProfileEntity> applyedUser; 

}
