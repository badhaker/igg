package com.innovationm.igotgame.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "opportunity_required_details")
@Setter
@Getter
@ToString
public class OpportunityRequiredDetailsEntity extends BaseEntity {

	@Column(name = "field_name", unique = true, nullable = false)
	private String fieldName;
	
	@Column(name = "field_value", nullable = false)
	private Integer fieldValue;
	@NotNull
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "opportunity_id")
	OpportunityEntity opportunity;

}
