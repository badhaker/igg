package com.innovationm.igotgame.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "organisation")
@Setter
@Getter
@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrganisationEntity extends AddressEntity{
	@Column(name="name",nullable=false)
	private String name;

	@Column(name="profile_url",nullable=true,columnDefinition="TEXT")
	private String profileUrl;

	@Column(name="about",nullable=true,columnDefinition="TEXT")
	private String about;
	
	@NotNull
	@OneToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="user_account_id")
	private UserAccountEntity userAccount;
	
	@Column(name="user_account_id",nullable = true, insertable= false, updatable= false)
	private Long userAccountId;

	@Column(name="website_url",nullable=true)
	private String websiteUrl;
	
	@Column(name="cin_no")
	private String cinNo;

}
