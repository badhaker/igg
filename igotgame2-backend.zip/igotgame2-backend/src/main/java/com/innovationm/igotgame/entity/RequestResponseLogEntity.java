package com.innovationm.igotgame.entity;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "request_response_log")
@EntityListeners(AuditingEntityListener.class)
public class RequestResponseLogEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false, updatable = false, insertable = false)
	private Long requestResponseId;

	@Column(name = "api_name", length = 200)
	private String apiName;

	@Column(name = "request_headers", length = 5000)
	private String requestHeaders;

	@Column(name = "request_url", length = 5000)
	private String requestUrl;

	@Column(name = "request_http_method", length = 50)
	private String requestHttpMethod;

	@Column(name = "request_string", columnDefinition = "TEXT")
	private String requestString;

	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdDate;
	
	@Column(name = "created_by")
	@CreatedBy
	private String createdBy = "system";
	
	@Column(name = "updated_date",updatable = true,nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date updatedDate;
	
	@Column(name = "updated_by")
	@LastModifiedBy
	private String updatedBy = "system";
	
	@Column(name = "response_string", columnDefinition = "LONGTEXT")
	private String responseString;

	@Column(name = "response_content_length", columnDefinition = "INTEGER")
	private int responseContentLength;
	
	@Column(name = "response_status", columnDefinition = "LONGTEXT")
	private String responseStatus;
	
	@Column(name = "response_time_in_seconds", columnDefinition = "Decimal(10,2)")
	private Double responseTime;

	
	/**Getters and Setters**/
	
	public Long getRequestResponseId() {
		return requestResponseId;
	}

	public void setRequestResponseId(Long requestResponseId) {
		this.requestResponseId = requestResponseId;
	}

	public String getApiName() {
		return apiName;
	}

	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	public String getRequestHeaders() {
		return requestHeaders;
	}

	public void setRequestHeaders(String requestHeaders) {
		this.requestHeaders = requestHeaders;
	}

	public String getRequestUrl() {
		return requestUrl;
	}

	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}

	public String getRequestHttpMethod() {
		return requestHttpMethod;
	}

	public void setRequestHttpMethod(String requestHttpMethod) {
		this.requestHttpMethod = requestHttpMethod;
	}

	public String getRequestString() {
		return requestString;
	}

	public void setRequestString(String requestString) {
		this.requestString = requestString;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getResponseString() {
		return responseString;
	}

	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	public int getResponseContentLength() {
		return responseContentLength;
	}

	public void setResponseContentLength(int responseContentLength) {
		this.responseContentLength = responseContentLength;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public Double getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(Double responseTime) {
		this.responseTime = responseTime;
	}
	
	

//	@Column(name = "request_content_length", columnDefinition = "INTEGER", length = 11)
//	private int requestContentLength;

//	@Column(name = "request_utc_time")
////	private String requestUtcTime;
//	private Date requestUtcTime;

//	@Column(name = "request_ist_time")
////	private String requestIstTime;
//	private Date requestIstTime;

//	@Column(name = "response_utc_time")
////	private String responseUtcTime;
//	private Date responseUtcTime;

//	@Column(name = "response_ist_time")
////	private String responseIstTime;
//	private Date responseIstTime;

//	@Column(name = "api_execution_time", columnDefinition = "INTEGER", length = 11)
//	private long apiExecutionTime;

//	@Column(name = "status", columnDefinition = "TINYINT", length = 1, nullable = false)
//	private int status;
		
//	@Column(name = "request_id", columnDefinition = "BIGINT", length = 20, nullable = false)
//	private Integer requestId;
	

//	@Column(name = "user_id", columnDefinition = "BIGINT", length = 20)
//	private BigInteger userId;
	
	

	
	

}

