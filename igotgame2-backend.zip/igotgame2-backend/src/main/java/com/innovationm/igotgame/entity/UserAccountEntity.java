package com.innovationm.igotgame.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "user_account")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserAccountEntity extends BaseEntity {

	@Column(name = "email", unique = true, nullable = false, columnDefinition = "varchar(45)")
	String email;
	@Column(name = "password", nullable = false, columnDefinition = "TEXT")
	String password;
	@Column(name = "contact_no", nullable = true)
	String contactNo;
	
	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.PERSIST }, fetch = FetchType.EAGER)
	private UserRoleEntity role;

	@Column(name = "isemail_verified", nullable = false, updatable = true, columnDefinition = "boolean default false")
	private boolean emailVerified;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userAccountEntity")
	private List<VerificationTokenEntity> verificationToken;

}
