package com.innovationm.igotgame.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import com.innovationm.igotgame.Enum.Gender;
import com.innovationm.igotgame.Enum.RecruiterStatus;
import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "user_profile")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserProfileEntity extends AddressEntity{

	@Column(name="first_name",nullable=true) 
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="about",nullable=true,columnDefinition="TEXT")
	private String about;
	
	@Column(name="designation")
	private String designation;
	
	//@Column(name="recruiter_personal_email", unique = true)
	//private String personalEmail;
	
	@Column(name="gender",nullable=true,updatable = true, columnDefinition = "enum('MALE','FEMALE') default 'MALE'")
	@Enumerated(EnumType.STRING)
	private Gender gender;
	
	@Column(name="profile_url",nullable=true)
	private String profileUrl;
	
	@Column(name="recruiter_status", columnDefinition = "enum('ACTIVE','INACTIVE') default 'ACTIVE'")
	@Enumerated(EnumType.STRING)
	private RecruiterStatus recruiterStatus;
	
	@Column(name="date_of_birth")
	private Date DateOfBirth;
	@NotNull
	@OneToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST }, fetch = FetchType.LAZY)
	@JoinColumn(name="user_account_id")
	private UserAccountEntity userAccount;
	
	@Column(name="user_account_id",nullable = true, insertable= false, updatable= false)
	private Long userAccountId;
	@Column(name="contact_visibility")
	private boolean contactVisibility;
	
	//@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,mappedBy="userProfile")	
	//private Set<CandidateSkillsMediaEntity> mediaDetailsEntity;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="userProfile")
	private Set<CandidateSkillsEntity> candidateSkillsEntity;
	
	@ManyToOne(cascade={ CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH, 
			CascadeType.PERSIST },fetch=FetchType.LAZY)
	@JoinColumn(name = "organisation_id",nullable=true)
	private OrganisationEntity organisationEntity;
	
	@Column(name="candiate_achievement")
	private String candidateAchievement;

}
