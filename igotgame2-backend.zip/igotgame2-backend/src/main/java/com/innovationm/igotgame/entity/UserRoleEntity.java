package com.innovationm.igotgame.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Table(name = "user_role")
@Getter
@Setter
@Entity
@ToString
public class UserRoleEntity extends BaseEntity {
	
	@Column(name = "name", unique = true, nullable = false)
	private String name;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "role")
	private List<UserAccountEntity> userAccountEntity;

}
