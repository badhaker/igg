package com.innovationm.igotgame.exception;

public class AppUpGradationException extends AppException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AppUpGradationException(String errorType, String errorCode, String message) {
		super(errorType, errorCode, message);
	
	}

}
