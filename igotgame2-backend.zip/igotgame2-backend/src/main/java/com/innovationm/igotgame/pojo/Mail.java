package com.innovationm.igotgame.pojo;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Mail {

	    private String from;
	    private String to;
	    private String subject;
	    private Map<String,Object> model;
	  
	}

