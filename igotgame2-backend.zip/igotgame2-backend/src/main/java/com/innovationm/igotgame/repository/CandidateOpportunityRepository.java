package com.innovationm.igotgame.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.igotgame.entity.CandidateOpportunityEntity;
import com.innovationm.igotgame.entity.UserProfileEntity;

public interface CandidateOpportunityRepository  extends JpaRepository<CandidateOpportunityEntity,Long>{

	List<CandidateOpportunityEntity> findByUserProfileId(UserProfileEntity profile);
	
	List<CandidateOpportunityEntity> findAllByOpportunity(Long opportunityId);  //yeh change hua hai

}
