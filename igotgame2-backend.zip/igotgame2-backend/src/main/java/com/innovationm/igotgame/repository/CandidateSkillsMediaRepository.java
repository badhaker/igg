package com.innovationm.igotgame.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.igotgame.entity.CandidateSkillsEntity;
import com.innovationm.igotgame.entity.CandidateSkillsMediaEntity;

public interface CandidateSkillsMediaRepository extends JpaRepository<CandidateSkillsMediaEntity, Long> {

	List<CandidateSkillsMediaEntity> findAllBySkillId(CandidateSkillsEntity skill);

}
