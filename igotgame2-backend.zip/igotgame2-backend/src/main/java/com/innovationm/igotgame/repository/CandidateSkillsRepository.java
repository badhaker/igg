package com.innovationm.igotgame.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovationm.igotgame.entity.CandidateSkillsEntity;
import com.innovationm.igotgame.entity.MasterCategoryEntity;
import com.innovationm.igotgame.entity.MasterSubCategoryEntity;
import com.innovationm.igotgame.entity.UserProfileEntity;

public interface CandidateSkillsRepository extends JpaRepository<CandidateSkillsEntity, Long> {

	List<CandidateSkillsEntity> findAllByUserProfile(UserProfileEntity userProfileEntity);
	
	@Query(value="SELECT * FROM candidate_skills p WHERE p.main_catrgory_id= ?1 AND p.sub_catrgory_id= ?2 AND p.candidate_profile_id= ?3 AND p.active!=false", 
	nativeQuery = true)
	CandidateSkillsEntity findByMainCategoryIdAndSubCategoryIdAndUserProfile(Long mainCategory,
			Long subCategory, Long userProfileEntity);

}
