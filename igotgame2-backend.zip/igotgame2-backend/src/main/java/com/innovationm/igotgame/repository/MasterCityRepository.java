package com.innovationm.igotgame.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.igotgame.entity.MSTCityEntity;

public interface MasterCityRepository extends JpaRepository<MSTCityEntity, Integer> {

}
