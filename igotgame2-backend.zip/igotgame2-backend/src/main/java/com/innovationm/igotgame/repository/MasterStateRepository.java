package com.innovationm.igotgame.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.igotgame.entity.MSTStateEntity;

public interface MasterStateRepository extends JpaRepository<MSTStateEntity, Integer> {

}
