package com.innovationm.igotgame.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.innovationm.igotgame.entity.OpportunityEntity;
import com.innovationm.igotgame.entity.UserAccountEntity;

public interface OpportunityRepository extends JpaRepository<OpportunityEntity,Long>{

	List<OpportunityEntity> findAllByRecruiterAccount(UserAccountEntity userAccount);

	
	@Query(value="SELECT count(*) FROM (Select * from user_profile p WHERE p.organisation_id= ?1) pro JOIN user_account a ON a.id= pro.user_account_id JOIN opportunity o ON a.id =o.recruiter_account_id WHERE o.status= 'OPEN' AND o.active!=false ", 
				nativeQuery = true)
	Long countActiceOpportunity(Long id);

}
