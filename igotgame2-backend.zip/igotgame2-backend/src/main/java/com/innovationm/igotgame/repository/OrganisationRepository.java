package com.innovationm.igotgame.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.igotgame.entity.OrganisationEntity;

public interface OrganisationRepository extends JpaRepository<OrganisationEntity,Long>{

	Optional<OrganisationEntity> findByUserAccountId(Long organizationAccountId);

}
