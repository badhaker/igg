package com.innovationm.igotgame.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.igotgame.entity.MasterCategoryEntity;
import com.innovationm.igotgame.entity.MasterSubCategoryEntity;
import com.innovationm.igotgame.response.SubCategoryListResponse;

public interface SubCategoryRepository extends JpaRepository<MasterSubCategoryEntity, Long> {

	List<MasterSubCategoryEntity> findAllByCategory(MasterCategoryEntity entity);

}
