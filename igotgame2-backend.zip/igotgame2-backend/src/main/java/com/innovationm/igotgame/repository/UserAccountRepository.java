package com.innovationm.igotgame.repository;

import java.util.Optional;

import javax.persistence.LockModeType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.innovationm.igotgame.entity.UserAccountEntity;

@Repository
public interface UserAccountRepository extends JpaRepository<UserAccountEntity,Long> {

	Optional<UserAccountEntity> findByEmail(String email);
	
	@Lock(LockModeType.NONE)
	@Query("select case when count(*) >0 then true else false end from UserAccountEntity as a where a.email=:email")
	public boolean doesEmailExists(@Param("email") String email);
	
	@Query("select case when count(*) >0 then true else false end from UserAccountEntity as a where a.contactNo=:contactNo")
	public boolean doesMobileNoExists(@Param("contactNo") String contactNo);

	Optional<UserAccountEntity> findByContactNo(String contactNo);

	boolean existsByEmail(String email);
}
