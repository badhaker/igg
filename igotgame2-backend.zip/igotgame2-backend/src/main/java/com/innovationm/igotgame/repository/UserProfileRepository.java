package com.innovationm.igotgame.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.innovationm.igotgame.Enum.FilterRecruiterValue;
import com.innovationm.igotgame.entity.OrganisationEntity;
import com.innovationm.igotgame.entity.UserAccountEntity;
import com.innovationm.igotgame.entity.UserProfileEntity;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfileEntity, Long> {

	UserProfileEntity findByUserAccount(UserAccountEntity userAccount);
	
	@Query(value="SELECT count(*) FROM user_profile p WHERE p.organisation_id= ?1 AND p.active!=false", 
			nativeQuery = true)
	Long countRecruiter(@Param("organisationId") Long organisationId);

	List<UserProfileEntity> findAllByOrganisationEntity(OrganisationEntity organisation);

	@Query(value="SELECT count(*) FROM (Select * from user_profile p WHERE p.organisation_id= ?1) pro JOIN user_account a ON a.id= pro.user_account_id  JOIN opportunity o ON a.id =o.recruiter_account_id JOIN candidate_opportunity co WHERE o.id= co.opportunity_id", 
					nativeQuery = true)
	Long countCandidate(@Param("organisationId") Long organisationId);

}
