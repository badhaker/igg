package com.innovationm.igotgame.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.innovationm.igotgame.entity.UserRoleEntity;

public interface UserRoleRepository extends JpaRepository<UserRoleEntity,Long>{

	Optional<UserRoleEntity> findByName(String role);
	//UserRoleEntity findByName(String roleRecruiter);

}
