package com.innovationm.igotgame.request;

import java.sql.Date;
import java.util.List;

import com.innovationm.igotgame.Enum.Gender;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CandidateProfileRequest {

	private String firstName;
	private String lastName;
	private Gender gender;
	private String contactNo;
	private Date dateOfBirth;
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode; 
	private String achievement;
	private String about;
	private boolean isContactVisible;
	//private List<CandidateSkillDetailRequest> skills;
	
}
