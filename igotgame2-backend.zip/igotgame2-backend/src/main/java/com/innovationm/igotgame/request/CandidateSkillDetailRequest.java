package com.innovationm.igotgame.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CandidateSkillDetailRequest {

	private Long mainCategoryid;
	private Long subCategoryId;
	private String description;
}
