/*package com.innovationm.igotgame.request;

import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
public class CandidateSkillMediaRequest {

	private String image;
}
*/