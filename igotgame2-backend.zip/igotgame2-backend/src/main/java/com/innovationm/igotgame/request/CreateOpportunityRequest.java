package com.innovationm.igotgame.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateOpportunityRequest {

	
	private String title;
	private Long mailSkillId;
	private Long subSkillId;
	private Long recruiterAccountId;
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode;
	private String about;
	private String ourWins;
}
