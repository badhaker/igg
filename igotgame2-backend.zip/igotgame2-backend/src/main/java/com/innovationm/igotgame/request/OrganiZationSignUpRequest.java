package com.innovationm.igotgame.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OrganiZationSignUpRequest {
	@Email(message = "Email is not valid")
	private String email;
	
	//@Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*\\p{Punct}){8,}$",message = "password should contain at least one upper case ,one lower case,one special character and one digit with minimum 8 digits")
	@Length(max = 15, min = 8, message = "Password should be minimum 8 characters long or maximum 15 characters long"  )
	private String password;
	
	@NotNull(message = "OrganisationName required")
	@NotBlank(message = "OrganisationName cant be Blank")
	@NotEmpty(message = "OrganisationName cant be empty")
	@Pattern(regexp = "^[A-Za-z\\s]*$",message = "Name should only contains letters")
	private String organisationName;
}
