package com.innovationm.igotgame.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrganisationProfileRequest {

	//private Long organizationAccountId;
	private String organizationName;
	private String contactNo;
	private String website;
	private String about;	
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode; 
}
