package com.innovationm.igotgame.request;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RecruiterProfileRequest {

	private String firstName;
	private String lastName;
	private String designation;
	private String about;	
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode;  
	private List<CandidateSkillDetailRequest> skills;
}
