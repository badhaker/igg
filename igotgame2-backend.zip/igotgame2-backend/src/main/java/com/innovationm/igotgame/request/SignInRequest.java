package com.innovationm.igotgame.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SignInRequest {
	@NotBlank(message = "Email should not be blank")
	@Email(message = "Email is not valid")
	private String email;
	@NotBlank(message = "Password should not be blank")
	@NotNull(message = "Password should not be Null")
	private String password;

}
