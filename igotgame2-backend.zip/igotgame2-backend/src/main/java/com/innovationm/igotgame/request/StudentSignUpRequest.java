package com.innovationm.igotgame.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StudentSignUpRequest {
	@Email(message = "Email is not valid")
	private String email;

 //@Pattern(regexp = "^((?=.*[a-z])(?=.*d)(?=.*[@#$%])(?=.*[A-Z]).{8,15})$",message = "password should contain at least one upper case ,one lower case,one special character and one digit with minimum 8 digits")
	@Length(max = 15, min = 8, message = "Password should be minimum 8 characters long or maximum 15 characters long"  )
	private String password;
	
	@NotNull(message = "FirstName required")
	@NotBlank(message = "FirstName cant be Blank")
	@NotEmpty(message = "FirstName cant be empty")
	@Pattern(regexp = "^[A-Za-z\\s]*$",message = "Name should only contains letters")
	private String firstName;
	
	private String lastName;
}
