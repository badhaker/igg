package com.innovationm.igotgame.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Setter
@Getter
public class AcceptedStudentsListResponse {
	
	private String name;

	private String age;

	private String gender;

	private String category;

	private String skills;

	private String city;
	
	private String addressLine1;
	
	private String country;
	
	private String state;
	
	private String pinCode;

}
