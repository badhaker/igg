package com.innovationm.igotgame.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.innovationm.igotgame.constant.AppConstants;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(Include.NON_NULL)
@Getter
@Setter
@ToString
public class BaseApiResponse<T> {
	//private ResponseStatus responseStatus;
	private  int statusCode;
	private T responseData;
	private String message;

	public BaseApiResponse(T responseData) {

		this.responseData = responseData;
		this.statusCode=AppConstants.StatusCodes.SUCCESS;
	}

	public BaseApiResponse() {
		this.responseData = null;
		this.statusCode=AppConstants.StatusCodes.SUCCESS;
	}
	
	public BaseApiResponse(T responseData,int statusCode) {

		this.responseData = responseData;
		this.statusCode=statusCode;
	}
	
	public BaseApiResponse(boolean error, int statusCode, T responseData, String message) {
		super();

		this.statusCode = statusCode;
		this.responseData = responseData;
		this.message = message;
	}
	
    public String convertToJson() throws JsonProcessingException {
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        return mapper.writeValueAsString(this);
    }

}
