package com.innovationm.igotgame.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class CandidateOpportunityListResponse {

	private Long opportunityId;
	private String title;
	private String mainSkill;
	private String subSkill;
	//private OpportunityStatus status;
	private String opportunityImgUrl; //I have added this
	private Long recruiterId;
	private Long organizationId;
	private String organizationName;
	private boolean requestAccepted;
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode;
	private String about;
	private String ourWins;
}
