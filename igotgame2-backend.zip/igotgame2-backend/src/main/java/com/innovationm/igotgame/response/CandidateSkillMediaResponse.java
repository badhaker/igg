package com.innovationm.igotgame.response;

import com.innovationm.igotgame.Enum.Gender;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class CandidateSkillMediaResponse {
	private Long fileId;
	private String fileUri;
}
