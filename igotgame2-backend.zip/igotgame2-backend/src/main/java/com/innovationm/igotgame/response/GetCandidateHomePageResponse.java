package com.innovationm.igotgame.response;

import java.util.List;

import com.innovationm.igotgame.Enum.Gender;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class GetCandidateHomePageResponse {

	private String name;
	private String profileUrl;
	private Long profilePercentage;
	private List<String> skills; 
}
