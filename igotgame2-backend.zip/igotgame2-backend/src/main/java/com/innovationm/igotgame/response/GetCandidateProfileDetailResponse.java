package com.innovationm.igotgame.response;

import java.util.Date;

import com.innovationm.igotgame.Enum.Gender;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class GetCandidateProfileDetailResponse {

	private String firstName;
	private String lastName;
	private Gender gender;
	private String contactNo;
	private String dateOfBirth;
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode; 
	private String profileUrl;
	private String achievement;
	private String about; 
	private boolean isContactVisible;
}
