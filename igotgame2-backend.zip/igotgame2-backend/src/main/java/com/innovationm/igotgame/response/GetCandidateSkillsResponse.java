package com.innovationm.igotgame.response;

import java.util.List;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class GetCandidateSkillsResponse {

	private Long skillId;
	private String mainCategory;
	private String subCategory;
	private String description;
	private List<CandidateSkillMediaResponse> mediaList;
}
