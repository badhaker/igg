package com.innovationm.igotgame.response;


import com.innovationm.igotgame.Enum.RecruiterStatus;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder

public class GetCommonDetailResponse {

	private Long AccountId;
	private String name;
	private String email;
	private String role;
	
	
}
