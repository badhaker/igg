package com.innovationm.igotgame.response;

import com.innovationm.igotgame.Enum.OpportunityStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class GetOpportunityDetailResponse {
	
	private String title;
	private String opportunityImgUrl;
	private String mainSkill;
	private String subSkill;
	private OpportunityStatus status;
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode;
	private String about;
	private String ourWins;
	private Long recruiterId;
	private Long organizationId;
	
	
}
