package com.innovationm.igotgame.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class GetOrganisationDashboardResponse {

	private Long organisationAccountId;
	private String organisationName;
	private Long recruiterCount;
	private Long candidateCount;
	private Long activeOpportunityCount;	
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode; 
	private String profileUrl;
}
