package com.innovationm.igotgame.response;


import com.innovationm.igotgame.Enum.RecruiterStatus;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder

public class GetRecruiterProfileResponse {

	private Long recruiterAccountId;
	private String firstName;
	private String lastName;
	private String designation;
	private String about;	
	private String addressLine1;
	private String country;
	private String state;
	private String city;
	private String pinCode;
	private String imgURL;
	private RecruiterStatus status;
	private String organisationName;
	private String organisationEmail;
	private String organisationContactNo;
	
	
}
