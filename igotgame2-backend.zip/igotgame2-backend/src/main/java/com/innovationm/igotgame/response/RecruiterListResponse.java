package com.innovationm.igotgame.response;


import com.innovationm.igotgame.Enum.RecruiterStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RecruiterListResponse {

private Long recruiterAccountId;
private String name;
private String email;
private RecruiterStatus status;
private String recuriterProfileUrl;

}
