package com.innovationm.igotgame.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class SubCategoryListResponse {

	private Long subCategoryId;
	private String subCategoryName;
}
