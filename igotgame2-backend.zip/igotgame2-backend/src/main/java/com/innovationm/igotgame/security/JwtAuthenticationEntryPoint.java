package com.innovationm.igotgame.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.exception.AppException;
import com.innovationm.igotgame.response.BaseApiResponse;


@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		BaseApiResponse<Object> baseApiResponse = new BaseApiResponse<>();
		AppException appException = new AppException(AppConstants.ErrorType.INVALID_TOKEN_ERROR_TYPE,
				AppConstants.ErrorCodes.INVALID_TOKEN_ERROR_CODE,
				AppConstants.ErrorMessage.INVALID_TOKEN_ERROR_MESSAGE);
		//baseApiResponse.setResponseData(appException);
		baseApiResponse.setStatusCode(AppConstants.StatusCodes.FAILURE);
		baseApiResponse.setMessage(appException.getMessage());
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//		response.setStatus(200);
		ObjectMapper Obj = new ObjectMapper();
		String json = Obj.writeValueAsString(baseApiResponse);
		// String json=responseEntity.convertToJson();
		response.getWriter().write(json);
	}

}
