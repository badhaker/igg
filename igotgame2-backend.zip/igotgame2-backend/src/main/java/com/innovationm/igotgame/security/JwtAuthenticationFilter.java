package com.innovationm.igotgame.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.innovationm.igotgame.constant.SecurityConstants;
import com.innovationm.igotgame.service.UserAccountService;


public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	private JwtTokenProvider tokenProvider;

	@Autowired
	private UserAccountService userAccountService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
			filterChain.doFilter(request, response);
		}else {
			String jwt = getJwtFromRequest(request);
			String header = request.getHeader(SecurityConstants.SecretKey.TOKEN_HEADER);

			if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
				String email=tokenProvider.getEmailIdFromJWT(jwt);
				String authToken = header.replace(SecurityConstants.SecretKey.TOKEN_PREFIX, "");
				UserDetails userDetails = userAccountService.loadUserByUsername(email);
				UserPrincipal userPrincipal=(UserPrincipal) userDetails;
				UsernamePasswordAuthenticationToken authentication = tokenProvider.getAuthentication(authToken,
						SecurityContextHolder.getContext().getAuthentication(), userDetails);
				authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request)); // this line is
				SecurityContextHolder.getContext().setAuthentication(authentication);
				request.setAttribute("userAccountId", userPrincipal.getId());			
//				request.setAttribute(AppConstants.Commons.EMPLOYEE_ID, userPrincipal.getId());
//				logger.info(empDetailsService.loadUserByEmail(email).getId());
				logger.info("Request Method : " + request.getMethod() + " Request URL : " + request.getRequestURL().toString());	
			}
			
			filterChain.doFilter(request, response);
		}
		
	}
	
	private String getJwtFromRequest(HttpServletRequest request) {
		String bearerToken = request.getHeader(SecurityConstants.SecretKey.TOKEN_HEADER);
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7, bearerToken.length());
		}
		return null;
	}
}
