package com.innovationm.igotgame.security;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.innovationm.igotgame.exception.AppException;

@JsonIgnoreProperties(value = {"cause","stackTrace","suppressed","localizedMessage"})
public class TokenNotValidException extends AppException {

	private static final long serialVersionUID = 1L;

	public TokenNotValidException( String errorType, String errorCode, String message) {
		super(errorType, errorCode, message);
	}
	
}
