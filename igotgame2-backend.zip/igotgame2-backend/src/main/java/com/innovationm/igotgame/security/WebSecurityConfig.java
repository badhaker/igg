package com.innovationm.igotgame.security;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.innovationm.igotgame.service.UserAccountService;

//@SuppressWarnings("deprecation")
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	private final UserAccountService userDetailsService;

	public WebSecurityConfig(UserAccountService userDetailsService) {
		this.userDetailsService = userDetailsService;
	}
	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private JwtAuthenticationEntryPoint unauthorizedHandler;

	@Bean
	public JwtAuthenticationFilter jwtAuthenticationFilter() {
		return new JwtAuthenticationFilter();
	}
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().configurationSource(corsConfigurationSource()).and().csrf().disable().authorizeRequests()
		
				.antMatchers(HttpMethod.POST, "/api/v1/studentSignUp").permitAll()

				.antMatchers(HttpMethod.GET, "/api/v1/verifyEmail").permitAll()
				
				.antMatchers(HttpMethod.POST, "/api/v1/signIn").permitAll()
				
				.antMatchers(HttpMethod.POST, "/api/v1/organisationSignUp").permitAll()
				
				.antMatchers(HttpMethod.POST, "/opportunity/create").permitAll()
				
				.antMatchers(HttpMethod.GET, "/opportunity/getDetails/**").permitAll()
				
				.antMatchers(HttpMethod.DELETE,"/opportunity/deleteOpportunity/**").permitAll()
				
				.antMatchers(HttpMethod.PUT,"/opportunity/updateStatus/**").permitAll()
				
				.antMatchers(HttpMethod.GET, "/opportunity/getListByRecruiterId/**").permitAll()
				
				.antMatchers(HttpMethod.POST, "/api/v1/recruiter/create").permitAll()
				
				.antMatchers(HttpMethod.PUT, "/recruiter/updateProfile").permitAll()
				
				.antMatchers(HttpMethod.GET, "/recruiter/**").permitAll()
				
				.antMatchers(HttpMethod.GET, "/opportunity/getListByCandidateId/**").permitAll()
				
				.antMatchers(HttpMethod.GET, "/candidate/**").permitAll()
				
				.antMatchers(HttpMethod.PUT, "/organisation/updateProfile").permitAll()
				
				.antMatchers(HttpMethod.GET, "/organisation/**").permitAll()
				
				.antMatchers(HttpMethod.GET, "/master/getCountryList/**","/master/getStateListId/**","/master/getCityListId/**").permitAll()//<-save
				
				.antMatchers(HttpMethod.GET, "/getMainCategoryList").permitAll()
				
				.antMatchers(HttpMethod.DELETE,"/recruiter/**").permitAll()
				
				.antMatchers(HttpMethod.PUT,"/recruiter/**").permitAll()
				
				.antMatchers(HttpMethod.GET, "/getSubCategoryList/**").permitAll()

				.anyRequest().authenticated().and().exceptionHandling().authenticationEntryPoint(unauthorizedHandler)
				
				.and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		
		http.addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);		
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/v2/api-docs", "/configuration/ui", "/swagger-resources/**", "/configuration/**",
				"/swagger-ui.html", "/webjars/**");
	}

	@Bean(BeanIds.AUTHENTICATION_MANAGER)
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService).passwordEncoder(encoder);
	}
	 @Bean
     CorsConfigurationSource corsConfigurationSource() {
         final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
         final CorsConfiguration config = new CorsConfiguration();
//         config.setAllowCredentials(true);
         config.addAllowedOrigin("*");
         config.addAllowedHeader("*");
         config.addAllowedMethod("*");
         config.setMaxAge(Duration.ofMinutes(60L));
         source.registerCorsConfiguration("/**", config);
         return source;
     }

}
