package com.innovationm.igotgame.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.innovationm.igotgame.request.CandidateProfileRequest;
import com.innovationm.igotgame.request.CandidateSkillDetailRequest;
import com.innovationm.igotgame.response.AcceptedStudentsListResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetCandidateHomePageResponse;
import com.innovationm.igotgame.response.GetCandidateProfileDetailResponse;
import com.innovationm.igotgame.response.GetCandidateSkillsResponse;
import com.innovationm.igotgame.response.GetOrganisationProfileDetailResponse;
import com.innovationm.igotgame.response.StudentListResponse;

public interface CandidateService {

	CommonSuccessResponse applyOnOpportunity(Long candidateAccountId, Long opportunityId);

	CommonSuccessResponse updateCandidateProfile(CandidateProfileRequest request, MultipartFile profileImage, String token) throws IOException;

	GetCandidateProfileDetailResponse getCandidateProfile(String token);

	CommonSuccessResponse addSkill(CandidateSkillDetailRequest skill, String token, MultipartFile[] media);

	List<GetCandidateSkillsResponse> getCandidateSkills(String token); //ask
	
	List<StudentListResponse> getStudentList(Long opportunityId);  //yeh phle bnaya tha
	
	List<AcceptedStudentsListResponse> getAcceptedStudentList(Long opportunityId); //yeh abhi bnaya hai

	GetCandidateHomePageResponse getCandidateHomePage(String token);

}
