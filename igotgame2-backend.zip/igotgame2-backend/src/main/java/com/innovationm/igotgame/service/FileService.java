package com.innovationm.igotgame.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {

	public String generatePreSignedUrlForFileDownload(String fileKey);
	
	public void uploadFile(MultipartFile multipartFile, String filePath) throws IOException;	

	public void deletefile(String keyName);

}
