package com.innovationm.igotgame.service;

import java.util.List;

import com.innovationm.igotgame.response.MasterCityResponse;
import com.innovationm.igotgame.response.MasterCountryResponse;
import com.innovationm.igotgame.response.MasterStateResponse;

public interface LocationService {

	public List<MasterCountryResponse> getAllCountry();
	
	public List<MasterStateResponse> getAllStatesByCountryId(Integer id);
	
	public List<MasterCityResponse> getAllCityByStateId(Integer id);

}
