package com.innovationm.igotgame.service;

import java.io.IOException;

import javax.mail.MessagingException;

import com.innovationm.igotgame.pojo.Mail;

public interface MailingService {

	public void sendMail(Mail mail) throws MessagingException, IOException;

}
