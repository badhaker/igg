package com.innovationm.igotgame.service;

import java.util.List;

import com.innovationm.igotgame.response.MainCategoryListResponse;

public interface MainCategoryService {

	List<MainCategoryListResponse> getMainCategoryList();

}
