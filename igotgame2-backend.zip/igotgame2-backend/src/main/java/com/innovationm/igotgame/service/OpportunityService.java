package com.innovationm.igotgame.service;


import java.util.List;


import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;
import com.innovationm.igotgame.Enum.OpportunityStatus;
import com.innovationm.igotgame.request.CreateOpportunityRequest;
import com.innovationm.igotgame.response.CandidateOpportunityListResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetOpportunityDetailResponse;
import com.innovationm.igotgame.response.RecruiterOpportunityListResponse;

public interface OpportunityService {


	CommonSuccessResponse createOpportunity(CreateOpportunityRequest createOpportunityRequest, MultipartFile opportunityImage) throws IOException;

	GetOpportunityDetailResponse getOpportunityDetail(Long opportunityId);

	CommonSuccessResponse deleteOpportunity(Long opportunityId);

	CommonSuccessResponse updateStatus(Long opportunityId, OpportunityStatus status);

	List<RecruiterOpportunityListResponse> getOpportunityListByRecruiterId(Long recruiterAccointId);

	List<CandidateOpportunityListResponse> getOpportunityListByCandidateId(Long studentAccountId);

}
