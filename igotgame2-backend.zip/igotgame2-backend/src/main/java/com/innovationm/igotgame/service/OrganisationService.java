package com.innovationm.igotgame.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.innovationm.igotgame.request.OrganisationProfileRequest;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetOrganisationDashboardResponse;
import com.innovationm.igotgame.response.GetOrganisationProfileDetailResponse;

public interface OrganisationService {

	CommonSuccessResponse upateOrganisationProfile(String token, OrganisationProfileRequest request, MultipartFile organisationImage) throws IOException;

	GetOrganisationProfileDetailResponse getOrganisationProfile(String token);

	GetOrganisationDashboardResponse getOrganisationDashboardDetail(String token);

}
