package com.innovationm.igotgame.service;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.web.multipart.MultipartFile;

import com.innovationm.igotgame.Enum.FilterRecruiterValue;
import com.innovationm.igotgame.Enum.RecruiterStatus;
import com.innovationm.igotgame.request.AddRecruiterRequest;
import com.innovationm.igotgame.request.RecruiterProfileRequest;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetRecruiterProfileResponse;
import com.innovationm.igotgame.response.RecruiterListResponse;

public interface RecruiterService {

CommonSuccessResponse addRecruiter(AddRecruiterRequest request, String token) throws MessagingException, IOException;

CommonSuccessResponse upateRecruiterProfile(String token, RecruiterProfileRequest request, MultipartFile profileImage) throws IOException;

GetRecruiterProfileResponse getProfileDetails(String token);

List<RecruiterListResponse> getRecruiterListByOrganisationId(String token, FilterRecruiterValue filterValue);


CommonSuccessResponse upateRecruiterProfileStatus(RecruiterStatus status, Long recruiterAccountId);

CommonSuccessResponse deleteRecruiterProfile( Long recruiterAccountId);


}
