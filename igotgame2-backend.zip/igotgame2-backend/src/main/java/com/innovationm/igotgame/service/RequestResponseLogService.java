package com.innovationm.igotgame.service;

import com.innovationm.igotgame.bo.RequestResponseLogBo;

public interface RequestResponseLogService {

	public void logRequestResponse(RequestResponseLogBo requestResponseLogBo);
}
