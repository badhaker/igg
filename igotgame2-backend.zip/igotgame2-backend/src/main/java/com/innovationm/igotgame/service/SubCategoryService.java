package com.innovationm.igotgame.service;

import java.util.List;

import com.innovationm.igotgame.response.MainCategoryListResponse;
import com.innovationm.igotgame.response.SubCategoryListResponse;

public interface SubCategoryService {

	List<SubCategoryListResponse> getSubCategoryListByMainCategory(Long mainCategoryId);

}
