package com.innovationm.igotgame.service;

import java.io.IOException;

import javax.mail.MessagingException;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.innovationm.igotgame.exception.AppException;
import com.innovationm.igotgame.request.OrganiZationSignUpRequest;
import com.innovationm.igotgame.request.SignInRequest;
import com.innovationm.igotgame.request.StudentSignUpRequest;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetCommonDetailResponse;
import com.innovationm.igotgame.response.SiginResponse;

public interface UserAccountService extends UserDetailsService {

	CommonSuccessResponse createStudent(StudentSignUpRequest request);

	CommonSuccessResponse createOrganisation(OrganiZationSignUpRequest signupRequest);

	CommonSuccessResponse verifyEmail(String token);

	SiginResponse signIn(SignInRequest signInRequest);

	GetCommonDetailResponse getCommonDetail(String token);

}
