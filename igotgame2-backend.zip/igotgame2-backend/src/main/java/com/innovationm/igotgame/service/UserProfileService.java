package com.innovationm.igotgame.service;

public interface UserProfileService {

}
