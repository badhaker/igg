package com.innovationm.igotgame.service.impl;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.entity.CandidateOpportunityEntity;
import com.innovationm.igotgame.entity.CandidateSkillsEntity;
import com.innovationm.igotgame.entity.CandidateSkillsMediaEntity;
import com.innovationm.igotgame.entity.MasterCategoryEntity;
import com.innovationm.igotgame.entity.MasterSubCategoryEntity;
import com.innovationm.igotgame.entity.OpportunityEntity;
import com.innovationm.igotgame.entity.UserAccountEntity;
import com.innovationm.igotgame.entity.UserProfileEntity;
import com.innovationm.igotgame.exception.BadRequestException;
import com.innovationm.igotgame.exception.EntityNotExistException;
import com.innovationm.igotgame.repository.CandidateOpportunityRepository;
import com.innovationm.igotgame.repository.CandidateSkillsMediaRepository;
import com.innovationm.igotgame.repository.CandidateSkillsRepository;
import com.innovationm.igotgame.repository.MainCategoryRepository;
import com.innovationm.igotgame.repository.OpportunityRepository;
import com.innovationm.igotgame.repository.SubCategoryRepository;
import com.innovationm.igotgame.repository.UserAccountRepository;
import com.innovationm.igotgame.repository.UserProfileRepository;
import com.innovationm.igotgame.request.CandidateProfileRequest;
import com.innovationm.igotgame.request.CandidateSkillDetailRequest;
import com.innovationm.igotgame.response.AcceptedStudentsListResponse;
import com.innovationm.igotgame.response.CandidateSkillMediaResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetCandidateHomePageResponse;
import com.innovationm.igotgame.response.GetCandidateProfileDetailResponse;
import com.innovationm.igotgame.response.GetCandidateSkillsResponse;
import com.innovationm.igotgame.response.StudentListResponse;
import com.innovationm.igotgame.security.JwtTokenProvider;
import com.innovationm.igotgame.service.CandidateService;

@Service

public class CandidateServiceImpl implements CandidateService {

	@Autowired
	private CandidateOpportunityRepository candidateOpportunityRepository;

	@Autowired
	private UserAccountRepository userAccountRepository;

	@Autowired
	private UserProfileRepository userProfileRepository;

	@Autowired
	private OpportunityRepository opportunityRepository;

	@Autowired
	private CandidateSkillsRepository candidateSkillsRepository;
	@Autowired
	private CandidateSkillsMediaRepository candidateSkillsMediaRepository;

	@Autowired
	private FileServiceImpl fileServiceImpl;
	@Autowired
	private MainCategoryRepository mainCategoryRepository;

	@Autowired
	private SubCategoryRepository subCategoryRepository;

	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	@Value("${aws.s3.candidate.profile_pic}")
	private String candidateProfilePath;

	@Value("${aws.s3.candidate.skill_media}")
	private String candiateSkillsMediaPath;

	@Override
	public CommonSuccessResponse applyOnOpportunity(Long candidateAccountId, Long opportunityId) {

		UserAccountEntity entity = userAccountRepository.findById(candidateAccountId).orElse(null);
		if (entity == null || entity.getActive() == false) {
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR,
					AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE,
					AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
		}
		OpportunityEntity opportunity = opportunityRepository.findById(opportunityId).orElse(null);
		if (opportunity == null || opportunity.getActive() == false) {
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR,
					AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE,
					AppConstants.ErrorMessage.OPPORTUNITY_NOT_EXISTS);
		}

		CandidateOpportunityEntity applyEntity = CandidateOpportunityEntity.builder().opportunity(opportunity)
				.userProfileId(userProfileRepository.findByUserAccount(entity)).requestAccepted(false).build();

		candidateOpportunityRepository.save(applyEntity);
		return new CommonSuccessResponse(true);
	}

	@Override
	public CommonSuccessResponse updateCandidateProfile(CandidateProfileRequest request, MultipartFile profileImage,
			String token) throws IOException {
		
		if (profileImage != null && !(profileImage.getSize() <= 0)
				&& !profileImage.getContentType().equals("image/jpeg")) {
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR,
					AppConstants.ErrorCodes.BAD_REQUEST_CODE, AppConstants.ErrorMessage.INVALID_FILE_FORMAT);
		}
		String candidatEmail = jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity candiateAccount = userAccountRepository.findByEmail(candidatEmail).orElse(null);
		UserProfileEntity userProfileEntity = userProfileRepository.findByUserAccount(candiateAccount);
		userProfileEntity.setFirstName(request.getFirstName());
		userProfileEntity.setLastName(request.getLastName());
		userProfileEntity.setAbout(request.getAbout());
		userProfileEntity.setContactVisibility(request.isContactVisible());
		userProfileEntity.setAddressLine1(request.getAddressLine1());
		userProfileEntity.setDateOfBirth(request.getDateOfBirth());
		userProfileEntity.setGender(request.getGender());
		userProfileEntity.setCountry(request.getCountry());

		userProfileEntity.setState(request.getState());
		userProfileEntity.setCity(request.getCity());
		userProfileEntity.setPinCode(request.getPinCode());
		userProfileEntity.setCandidateAchievement(request.getAchievement());
		userProfileRepository.save(userProfileEntity);
		if (request.getContactNo() == null || request.getContactNo() == "") {

			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR,
					AppConstants.ErrorCodes.BAD_REQUEST_CODE, AppConstants.ErrorMessage.INVALID_CONTACT_NO);
		}
		candiateAccount.setContactNo(request.getContactNo());
		userAccountRepository.save(candiateAccount);
		if (profileImage != null && !(profileImage.getSize() <= 0)) {
			String originalFileName = profileImage.getOriginalFilename();
			String extension = originalFileName.substring(originalFileName.lastIndexOf("."));
			String filaPathPrefix = candidateProfilePath;
			String filePathSuffix = candiateAccount.getId() + "_Candidate_Profile" + extension;
			String filePath = filaPathPrefix + AppConstants.Commons.SLASH + filePathSuffix;
			fileServiceImpl.uploadFile(profileImage, filePath);
			userProfileEntity.setProfileUrl(filePathSuffix);
			userProfileRepository.save(userProfileEntity);
		}

		return new CommonSuccessResponse(true);
	}

	@Override
	public GetCandidateProfileDetailResponse getCandidateProfile(String token) {
		String candidatEmail = jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity candiateAccount = userAccountRepository.findByEmail(candidatEmail).orElse(null);
		UserProfileEntity userProfileEntity = userProfileRepository.findByUserAccount(candiateAccount);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		String dob = null;
		if (userProfileEntity.getDateOfBirth() != null)
			dob = formatter.format(userProfileEntity.getDateOfBirth());
		GetCandidateProfileDetailResponse profileDetails = GetCandidateProfileDetailResponse.builder()
				.firstName(userProfileEntity.getFirstName()).lastName(userProfileEntity.getLastName())
				.about(userProfileEntity.getAbout()).isContactVisible(userProfileEntity.isContactVisibility())
				.contactNo(candiateAccount.getContactNo()).dateOfBirth(dob).gender(userProfileEntity.getGender())
				.addressLine1(userProfileEntity.getAddressLine1()).country(userProfileEntity.getCountry())
				.state(userProfileEntity.getState()).city(userProfileEntity.getCity())
				.pinCode(userProfileEntity.getPinCode()).profileUrl(null)
				.achievement(userProfileEntity.getCandidateAchievement()).build();
		if (userProfileEntity.getProfileUrl() != null) {
			profileDetails.setProfileUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(
					candidateProfilePath + AppConstants.Commons.SLASH + userProfileEntity.getProfileUrl()));
		}
		return profileDetails;
	}

	@Override
	public CommonSuccessResponse addSkill(CandidateSkillDetailRequest skill, String token, MultipartFile[] media) {
		String candidatEmail = jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity candiateAccount = userAccountRepository.findByEmail(candidatEmail).orElse(null);
		UserProfileEntity userProfileEntity = userProfileRepository.findByUserAccount(candiateAccount);
		MasterCategoryEntity mainCategory = mainCategoryRepository.findById(skill.getMainCategoryid()).orElse(null);
		MasterSubCategoryEntity subCategory = subCategoryRepository.findById(skill.getSubCategoryId()).orElse(null);

		if (mainCategory == null || subCategory == null) {
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR,
					AppConstants.ErrorCodes.BAD_REQUEST_CODE, AppConstants.ErrorMessage.INVALID_CATEGORY_NO);
		}
		CandidateSkillsEntity entity = candidateSkillsRepository.findByMainCategoryIdAndSubCategoryIdAndUserProfile(
				mainCategory.getId(), subCategory.getId(), userProfileEntity.getId());
		if (!(entity == null || entity.getActive() == false)) {
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR,
					AppConstants.ErrorCodes.BAD_REQUEST_CODE, AppConstants.ErrorMessage.ALREADY_ADDED_SKILL);
		}
		CandidateSkillsEntity skillEntity = CandidateSkillsEntity.builder().mainCategoryId(skill.getMainCategoryid())
				.subCategoryId(skill.getSubCategoryId()).description(skill.getDescription())
				.userProfile(userProfileEntity).build();

		CandidateSkillsEntity savedSkillEntity = candidateSkillsRepository.save(skillEntity);
		Arrays.asList(media).stream().forEach(file -> {
			try {
				saveSkillMedia(file, savedSkillEntity);
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		});
		return new CommonSuccessResponse(true);
	}

	private void saveSkillMedia(MultipartFile file, CandidateSkillsEntity skillEntity) throws IOException {

		CandidateSkillsMediaEntity mediaEntity = CandidateSkillsMediaEntity.builder().mediaUrl("").skillId(skillEntity)
				.build();
		CandidateSkillsMediaEntity m = candidateSkillsMediaRepository.save(mediaEntity);
		String originalFileName = file.getOriginalFilename();
		String extension = originalFileName.substring(originalFileName.lastIndexOf("."));
		String filaPathPrefix = candiateSkillsMediaPath;
		String filePathSuffix = m.getId() + "_" + skillEntity.getId() + "_Candidate_Skill_Media" + extension;
		String filePath = filaPathPrefix + AppConstants.Commons.SLASH + filePathSuffix;
		fileServiceImpl.uploadFile(file, filePath);

		m.setMediaUrl(filePathSuffix);
		candidateSkillsMediaRepository.save(mediaEntity);
	}

	@Override
	public List<GetCandidateSkillsResponse> getCandidateSkills(String token) { //ask
		String candidatEmail = jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity candiateAccount = userAccountRepository.findByEmail(candidatEmail).orElse(null);
		UserProfileEntity userProfileEntity = userProfileRepository.findByUserAccount(candiateAccount);
		List<GetCandidateSkillsResponse> resp = candidateSkillsRepository.findAllByUserProfile(userProfileEntity)
				.stream().filter(a -> a.getActive() != false).map(skill -> convertToSkillResponse(skill))
				.collect(Collectors.toList());
		return resp;
	}

	private GetCandidateSkillsResponse convertToSkillResponse(CandidateSkillsEntity skill) {
		GetCandidateSkillsResponse resp = GetCandidateSkillsResponse.builder().skillId(skill.getId())
				.mainCategory(mainCategoryRepository.findById(skill.getMainCategoryId()).orElse(null).getName())
				.subCategory(subCategoryRepository.findById(skill.getSubCategoryId()).orElse(null).getName())
				.description(skill.getDescription()).build();
		List<CandidateSkillMediaResponse> mediaList = candidateSkillsMediaRepository.findAllBySkillId(skill).stream()
				.filter(a -> a.getActive() != false).map(file -> getMediaList(file)).collect(Collectors.toList());
		resp.setMediaList(mediaList);
		return resp;
	}

	private CandidateSkillMediaResponse getMediaList(CandidateSkillsMediaEntity file) {
		CandidateSkillMediaResponse fileResp = CandidateSkillMediaResponse.builder().fileId(file.getId()).fileUri(null)
				.build();
		if (file.getMediaUrl() != null)
			fileResp.setFileUri(fileServiceImpl.generatePreSignedUrlForFileDownload(
					candiateSkillsMediaPath + AppConstants.Commons.SLASH + file.getMediaUrl()));
		return fileResp;
	}

	@Override
	public GetCandidateHomePageResponse getCandidateHomePage(String token) {

		String candidatEmail = jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity candiateAccount = userAccountRepository.findByEmail(candidatEmail).orElse(null);
		UserProfileEntity userProfileEntity = userProfileRepository.findByUserAccount(candiateAccount);

		Long percentage = countProfilePercentage(userProfileEntity);
		String name = userProfileEntity.getFirstName();
		if (userProfileEntity.getLastName() != null) {
			name = userProfileEntity.getFirstName() + " " + userProfileEntity.getLastName();
		}
		List<String> resp = candidateSkillsRepository.findAllByUserProfile(userProfileEntity).stream()
				.filter(a -> a.getActive() != false).map(skill -> convertToSkillResponseHomePage(skill))
				.collect(Collectors.toList());
		GetCandidateHomePageResponse homepage = GetCandidateHomePageResponse.builder().name(name)
				.profilePercentage(percentage).skills(resp).profileUrl(name).build();
		if (userProfileEntity.getProfileUrl() != null) {
			homepage.setProfileUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(
					candidateProfilePath + AppConstants.Commons.SLASH + userProfileEntity.getProfileUrl()));
		}
		return homepage;
	}

	private Long countProfilePercentage(UserProfileEntity userProfileEntity) {
		Long count = 0l;
		if (userProfileEntity.getFirstName() != null)
			count = count + AppConstants.CandidateHomePage.NAME;
		if (userProfileEntity.getGender() != null)
			count = count + AppConstants.CandidateHomePage.GENDER;
		if (userProfileEntity.getDateOfBirth() != null)
			count = count + AppConstants.CandidateHomePage.DOB;
		if (userProfileEntity.getProfileUrl() != null)
			count = count + AppConstants.CandidateHomePage.PROFILE;
		if (userProfileEntity.getAddressLine1() != null)
			count = count + AppConstants.CandidateHomePage.ADDRESS;
		if (!userProfileEntity.getCandidateSkillsEntity().isEmpty() )
			count = count + AppConstants.CandidateHomePage.SKILL;
		if (userProfileEntity.getAbout() != null)
			count = count + AppConstants.CandidateHomePage.ABOUT;
		if (userAccountRepository.findById(userProfileEntity.getUserAccount().getId()) != null)
			count = count + AppConstants.CandidateHomePage.CONTACT;
		return count;
	}

	private String convertToSkillResponseHomePage(CandidateSkillsEntity skill) {
		return subCategoryRepository.findById(skill.getSubCategoryId()).orElse(null).getName();
	}

	@Override
	public List<StudentListResponse> getStudentList(Long opportunityId) {
		
		List<CandidateOpportunityEntity> candidateOpportunityEntity = candidateOpportunityRepository.findAllByOpportunity(opportunityId);
		
		//List<UserProfileEntity> userProfileEntity = userProfileRepository.findAllByUserProfileEntity(candidateOpportunityEntity.getUserProfileId());
		//candidateOpportunityEntity.stream()
		
		//List<StudentListResponse> listresponse=userProfileEntity.stream().map(profile->convertToModel(profile)).collect(Collectors.toList());
		
		
		return null; //listresponse
	}

	public StudentListResponse convertToModel(UserProfileEntity userprofile) {

		// UserAccountEntity
		// recruiterAccount=accountRepo.findById(userprofile.getUserAccount().getId()).orElse(null);

		return StudentListResponse.builder()
				.name(userprofile.getFirstName() + " " + userprofile.getLastName())
				.gender(userprofile.getGender().toString()) 
				.category(null)
				.skills(null)
				.city(userprofile.getCity())
				.addressLine1(userprofile.getAddressLine1())
				.country(userprofile.getCountry())
				.state(userprofile.getState())
				.pinCode(userprofile.getPinCode())
				.build();

	}
	
	@Override
	public List<AcceptedStudentsListResponse> getAcceptedStudentList(Long opportunityId) {
		
		List<CandidateOpportunityEntity> candidateOpportunityEntity = candidateOpportunityRepository.findAllByOpportunity(opportunityId);
		
		//List<UserProfileEntity> userProfileEntity = userProfileRepository.findAllByUserProfileEntity(candidateOpportunityEntity.getUserProfileId());
		//candidateOpportunityEntity.stream()
		
		//List<AcceptedStudentsListResponse> listresponse=userProfileEntity.stream().map(profile->convertToModelAccepted(profile)).collect(Collectors.toList());
		
		
		return null;
	}

	public AcceptedStudentsListResponse convertToModelAccepted(UserProfileEntity userprofile) {

		

		return AcceptedStudentsListResponse.builder()
				.name(userprofile.getFirstName() + " " + userprofile.getLastName())
				.gender(userprofile.getGender().toString()) 
				.category(null)
				.skills(null)
				.city(userprofile.getCity())
				.addressLine1(userprofile.getAddressLine1())
				.country(userprofile.getCountry())
				.state(userprofile.getState())
				.pinCode(userprofile.getPinCode())
				.build();

	}

}
