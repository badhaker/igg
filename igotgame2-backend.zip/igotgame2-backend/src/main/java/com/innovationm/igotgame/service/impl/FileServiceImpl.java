package com.innovationm.igotgame.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.HttpMethod;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.exception.AppException;
import com.innovationm.igotgame.service.FileService;

@Service
public class FileServiceImpl implements FileService{

	@Autowired
	private AmazonS3 amazonS3;
	
	@Value("${aws.s3.bucket-name}")
	private String bucketName;
	
	@Override
	public String generatePreSignedUrlForFileDownload(String fileKey) {
		if (fileKey == null || fileKey.isEmpty()) {
			throw new AppException(AppConstants.ErrorType.PATH_NULL_FOR_FILE,
					AppConstants.ErrorCodes.PATH_NULL_FOR_FILE_ERROR_CODE,
					AppConstants.ErrorMessage.PATH_NULL_FOR_FILE_ERROR_MESSAGE);
		}
		GeneratePresignedUrlRequest presignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, fileKey)
				.withMethod(HttpMethod.GET);
		URL presignedUrl = amazonS3.generatePresignedUrl(presignedUrlRequest);
		String presignedUrlInString = presignedUrl.toString();
		return presignedUrlInString;
	}

	@Async
	public void uploadFile(MultipartFile multipartFile, String filePath) throws IOException {
		InputStream streamToUpload = null;
		ObjectMetadata metaData = new ObjectMetadata();
		metaData.setContentType(multipartFile.getContentType());
		metaData.setContentLength(multipartFile.getSize());
		try {
			streamToUpload = multipartFile.getInputStream();
			amazonS3.putObject(new PutObjectRequest(bucketName, filePath, streamToUpload, metaData)
					.withCannedAcl(CannedAccessControlList.Private));
		} catch (SdkClientException e) {
			throw new AppException(AppConstants.ErrorType.UPLOAD_FILE_EXCEPTION,
					AppConstants.ErrorCodes.UPLOAD_FILE_EXCEPTION_CODE, e.getMessage());

		} finally {
			streamToUpload.close();
		}
	}
	
	@Async
	public void deletefile(String keyName) {
		if (keyName==null || keyName =="") {
			return;
		}
		DeleteObjectRequest deleteRequest=new DeleteObjectRequest(bucketName,keyName);
		amazonS3.deleteObject(deleteRequest);
	}

}
