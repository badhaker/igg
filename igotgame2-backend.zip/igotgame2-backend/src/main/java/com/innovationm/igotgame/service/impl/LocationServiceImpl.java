package com.innovationm.igotgame.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import com.innovationm.igotgame.constant.AppConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.igotgame.entity.MSTCityEntity;
import com.innovationm.igotgame.entity.MSTCountryEntity;
import com.innovationm.igotgame.entity.MSTStateEntity;
import com.innovationm.igotgame.exception.CountryNotFoundException;
import com.innovationm.igotgame.exception.MasterStateNotFoundException;
import com.innovationm.igotgame.repository.MasterCountryRepository;
import com.innovationm.igotgame.repository.MasterStateRepository;
import com.innovationm.igotgame.response.MasterCityResponse;
import com.innovationm.igotgame.response.MasterCountryResponse;
import com.innovationm.igotgame.response.MasterStateResponse;
import com.innovationm.igotgame.service.LocationService;

@Service
public class LocationServiceImpl implements LocationService {

	@Autowired
	MasterCountryRepository masterCountryRepository;
	
	@Autowired
	MasterStateRepository masterStateRepository;
	

	@Override
	public List<MasterCountryResponse> getAllCountry() {
		
		return masterCountryRepository.findAll().stream().map(country -> convertToModel(country))
				.collect(Collectors.toList());
		
	}
	
	@Override
	public List<MasterStateResponse> getAllStatesByCountryId(Integer id) { //country
		
		MSTCountryEntity mstCountry = masterCountryRepository.findById(id)

				.orElseThrow(() -> new CountryNotFoundException(AppConstants.ErrorType.MASTER_COUNTRY_EXIST_ERROR,
						AppConstants.ErrorCodes.MASTER_COUNTRY_ERROR_CODE,
						AppConstants.ErrorMessage.MASTER_COUNTRY_NOT_EXTIS_MESSAGE));

		return mstCountry.getState().stream().map(states -> convertToModel(states)).collect(Collectors.toList());
	}
	
	@Override
	public List<MasterCityResponse> getAllCityByStateId(Integer id) {
		MSTStateEntity mstCountry = masterStateRepository.findById(id)

				.orElseThrow(() -> new MasterStateNotFoundException(AppConstants.ErrorType.MASTER_STATE_EXIST_ERROR,
						AppConstants.ErrorCodes.MASTER_STATE_ERROR_CODE,
						AppConstants.ErrorMessage.MASTER_STATE_NOT_EXTIS_MESSAGE));

		return mstCountry.getCity().stream().map(city -> convertToModel(city)).collect(Collectors.toList());
	}
	
	MasterCountryResponse convertToModel(MSTCountryEntity entity) { //country

		return MasterCountryResponse.builder()
				.id(entity.getId())
				.name(entity.getName())
				.phoneCode(entity.getPhoneCode())
				.shortName(entity.getShortName())
				.currency(entity.getCurrency())
				.status(entity.getStatus())
				.build();

	}

	public MasterStateResponse convertToModel(MSTStateEntity entity) {

		return MasterStateResponse.builder()
				.id(entity.getId())
				.name(entity.getName())
				.status(entity.getStatus())
				.build();

	}
	
	MasterCityResponse convertToModel(MSTCityEntity entity) {  //yeh add kiye hai abhi

		return MasterCityResponse.builder()
				.id(entity.getId())
				.name(entity.getName())
				.status(entity.getStatus())
				.build();

	}

}
