package com.innovationm.igotgame.service.impl;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring4.SpringTemplateEngine;

import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.pojo.Mail;
import com.innovationm.igotgame.service.MailingService;

@Service
public class MailingServiceImpl implements MailingService {
	
	
    @Value("${spring.mail.username}")
    private  String  empEmail;
	private JavaMailSender javaMailSender;
	@Autowired
	SpringTemplateEngine templateEngine;
	Logger log=LogManager.getLogger(MailingServiceImpl.class);

	public MailingServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Autowired
	public MailingServiceImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	@Override
	public void sendMail(Mail mail) throws MessagingException, IOException {
		MimeMessage message = javaMailSender.createMimeMessage();
		message.setFrom(empEmail);
		MimeMessageHelper helper = new MimeMessageHelper(message, 3, StandardCharsets.UTF_8.name());
		System.out.println("\n" + Thread.currentThread().getName() + "\n");
		Context context = new Context();
		context.setVariables(mail.getModel());
		String html=null;
		if(mail.getSubject().equals(AppConstants.MailConstant.SIGNUP))	
		{
			html = templateEngine.process("email-template-onboarding", context);
		}
		
		if(mail.getSubject().equals(AppConstants.MailConstant.RECRUITER_CREATED))
		{
			html = templateEngine.process("email-template-recruiter-created", context);
		}
		
		helper.setTo(mail.getTo());
		helper.setText(html, true);
		helper.setSubject(mail.getSubject());
		log.info("@@@@@@@@@@@@@@@@@@@@@@@sending mail using javaMailSender@@@@@@@@@@@@@");
		
		javaMailSender.send(message);
	}

}
