package com.innovationm.igotgame.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.igotgame.entity.MasterCategoryEntity;
import com.innovationm.igotgame.repository.MainCategoryRepository;
import com.innovationm.igotgame.response.MainCategoryListResponse;
import com.innovationm.igotgame.service.MainCategoryService;
@Service
public class MainCategoryServiceImpl implements MainCategoryService {

	@Autowired
	private MainCategoryRepository MainCategoryRepository;
	
	@Override
	public List<MainCategoryListResponse> getMainCategoryList() {
		return MainCategoryRepository.findAll().stream().map(cat-> convertToModel(cat)).collect(Collectors.toList());
		
	}

	private MainCategoryListResponse convertToModel(MasterCategoryEntity cat) {
		return MainCategoryListResponse.builder()
				.categoryId(cat.getId())
				.categoryName(cat.getName())
				.build();
	}

}
