package com.innovationm.igotgame.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.innovationm.igotgame.Enum.OpportunityStatus;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.entity.CandidateOpportunityEntity;
import com.innovationm.igotgame.entity.OpportunityEntity;
import com.innovationm.igotgame.entity.UserAccountEntity;
import com.innovationm.igotgame.entity.UserProfileEntity;
import com.innovationm.igotgame.exception.BadRequestException;
import com.innovationm.igotgame.exception.EntityNotExistException;
import com.innovationm.igotgame.repository.CandidateOpportunityRepository;
import com.innovationm.igotgame.repository.MainCategoryRepository;
import com.innovationm.igotgame.repository.OpportunityRepository;
import com.innovationm.igotgame.repository.SubCategoryRepository;
import com.innovationm.igotgame.repository.UserAccountRepository;
import com.innovationm.igotgame.repository.UserProfileRepository;
import com.innovationm.igotgame.request.CreateOpportunityRequest;
import com.innovationm.igotgame.response.CandidateOpportunityListResponse;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetOpportunityDetailResponse;
import com.innovationm.igotgame.response.RecruiterOpportunityListResponse;
import com.innovationm.igotgame.service.OpportunityService;

@Service
public class OpportunityServiceImpl implements OpportunityService {
	@Autowired
	private OpportunityRepository opportunityRepository;

	@Autowired
	private UserAccountRepository userAccountRepository;
	
	@Autowired
	private UserProfileRepository userProfileRepository;
	
	@Autowired
	private CandidateOpportunityRepository candidateOpportunityRepository;
	@Autowired
	private FileServiceImpl fileServiceImpl;
	@Autowired
	private MainCategoryRepository mainCategoryRepository;
	
	@Autowired
	private SubCategoryRepository subCategoryRepository;
	
	
	
	@Override
	public CommonSuccessResponse createOpportunity(CreateOpportunityRequest request,MultipartFile opportunityImage) throws IOException {
		if(opportunityImage!=null && !(opportunityImage.getSize()<=0) && !opportunityImage.getContentType().equals("image/jpeg"))
		{ 
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
				AppConstants.ErrorMessage.INVALID_FILE_FORMAT); 
		}
		UserAccountEntity entity=userAccountRepository.findById(request.getRecruiterAccountId()).orElse(null);
		if (entity==null || entity.getActive()==false)
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
		}
		
		OpportunityEntity opportunityCreated = 
				OpportunityEntity
				.builder()
				.title(request.getTitle())
				.categoryEntity(mainCategoryRepository.findById(request.getMailSkillId()).orElse(null))
				.subCategoryEntity(subCategoryRepository.findById(request.getSubSkillId()).orElse(null))
				.about(request.getAbout())
				.ourWins(request.getOurWins())
				.recruiterAccount(userAccountRepository.findById(request.getRecruiterAccountId()).orElse(null))
				.status(OpportunityStatus.OPEN)
				.build();
		
		opportunityCreated.setAddressLine1(request.getAddressLine1());
		opportunityCreated.setCountry(request.getCountry());
		opportunityCreated.setState(request.getState());
		opportunityCreated.setCity(request.getCity());
		opportunityCreated.setPinCode(request.getPinCode());

		//opportunityRepository.save(opportunityCreated);
		String originalFileName=opportunityImage.getOriginalFilename();
		String extension=originalFileName.substring(originalFileName.lastIndexOf("."));
		String filePath="data/opportunity/opportunity_pic_"+opportunityCreated.getId()+extension;
		fileServiceImpl.uploadFile(opportunityImage, filePath);
		opportunityCreated.setOpportunityImagePath(filePath);
		opportunityRepository.save(opportunityCreated);
		return new CommonSuccessResponse(true);
	}

	@Override
	public GetOpportunityDetailResponse getOpportunityDetail(Long opportunityId) {
		OpportunityEntity entity=opportunityRepository.findById(opportunityId).orElse(null);
		if (entity==null || entity.getActive()==false)
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.OPPORTUNITY_NOT_EXISTS);
		}
		
		return GetOpportunityDetailResponse.builder()
		.title(entity.getTitle())
		.opportunityImgUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(entity.getOpportunityImagePath()))
		.mainSkill(entity.getCategoryEntity().getName())
		.subSkill(entity.getSubCategoryEntity().getName())
		.status(entity.getStatus())
		.addressLine1(entity.getAddressLine1())
		.country(entity.getCountry())
		.state(entity.getState())
		.city(entity.getCity())
		.pinCode(entity.getPinCode())
		.about(entity.getAbout())
		.ourWins(entity.getOurWins())
		.recruiterId(entity.getRecruiterAccount().getId())
		.organizationId(userProfileRepository.findByUserAccount(entity.getRecruiterAccount()).getOrganisationEntity().getId())
		.build();
	}

	@Override
	public CommonSuccessResponse deleteOpportunity(Long opportunityId) {
		OpportunityEntity entity=opportunityRepository.findById(opportunityId).orElse(null);
		if (entity==null || entity.getActive()==false)
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, 
					AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.OPPORTUNITY_NOT_EXISTS);
		}
		entity.setActive(false);
		fileServiceImpl.deletefile(entity.getOpportunityImagePath());
		opportunityRepository.save(entity);
		return new CommonSuccessResponse(true);
	}

	@Override
	public CommonSuccessResponse updateStatus(Long opportunityId, OpportunityStatus status) {
		OpportunityEntity entity=opportunityRepository.findById(opportunityId).orElse(null);
		if (entity==null || entity.getActive()==false)
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, 
					AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.OPPORTUNITY_NOT_EXISTS);
		}
		entity.setStatus(status);
		opportunityRepository.save(entity);
		return new CommonSuccessResponse(true);
	}

	@Override
	public List<RecruiterOpportunityListResponse> getOpportunityListByRecruiterId(Long recruiterAccointId) { //yeh shi hai
		
		UserAccountEntity userAccount=userAccountRepository.findById(recruiterAccointId).orElse(null);
		if (userAccount==null || userAccount.getActive()==false)
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
		}
		
		List<OpportunityEntity> opportunityList= opportunityRepository.findAllByRecruiterAccount(userAccount);
		return opportunityList.stream().filter(op-> op.getActive()!=false).map(opp-> convertToOpportunityListModal(opp)).collect(Collectors.toList());
	}

	private RecruiterOpportunityListResponse convertToOpportunityListModal(OpportunityEntity opp) {     //....
		
		return RecruiterOpportunityListResponse.builder()
				.opportunityId(opp.getId())
				.title(opp.getTitle())
				.opportunityImgUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(opp.getOpportunityImagePath()))    //....this is correct
				.mainSkill(opp.getCategoryEntity().getName())
				.subSkill(opp.getSubCategoryEntity().getName())
				.status(opp.getStatus())
				.addressLine1(opp.getAddressLine1())
				.country(opp.getCountry())
				.state(opp.getState())
				.city(opp.getCity())
				.pinCode(opp.getPinCode())
				.about(opp.getAbout())
				.ourWins(opp.getOurWins())
				.build();
	}

	@Override
	public List<CandidateOpportunityListResponse> getOpportunityListByCandidateId(Long candidateAccountId) {
		UserAccountEntity userAccount=userAccountRepository.findById(candidateAccountId).orElse(null);
		if (userAccount==null || userAccount.getActive()==false)
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.STUDENT_NOT_EXISTS);
		}
		UserProfileEntity profile=userProfileRepository.findByUserAccount(userAccount);
		if (profile==null || profile.getActive()==false)
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
		}
		return candidateOpportunityRepository.findByUserProfileId(profile).stream().map(co-> convertToCandidateOppList(co,profile)).collect(Collectors.toList());
			
	}

	private CandidateOpportunityListResponse convertToCandidateOppList(CandidateOpportunityEntity co, UserProfileEntity profile) {
		OpportunityEntity opportunity=opportunityRepository.findById(co.getOpportunity().getId()).orElse(null);
		
		return CandidateOpportunityListResponse.builder()
				.opportunityId(co.getOpportunity().getId())
				.title(opportunity.getTitle())
				.opportunityImgUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(co.getOpportunityImagePath())) //""ask this...""  -> check CandidateOpportunityEntity
				.mainSkill(opportunity.getCategoryEntity().getName())
				.subSkill(opportunity.getSubCategoryEntity().getName())
				.recruiterId(opportunity.getRecruiterAccount().getId())
				.organizationId(userProfileRepository.findByUserAccount(opportunity.getRecruiterAccount()).getOrganisationEntity().getId())
				.organizationName(userProfileRepository.findByUserAccount(opportunity.getRecruiterAccount()).getOrganisationEntity().getName())
				.addressLine1(opportunity.getAddressLine1())
				.country(opportunity.getCountry())
				.state(opportunity.getState())
				.city(opportunity.getCity())
				.pinCode(opportunity.getPinCode())
				.about(opportunity.getAbout())
				.ourWins(opportunity.getOurWins())
				.build();
	}

}
