package com.innovationm.igotgame.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.entity.OrganisationEntity;
import com.innovationm.igotgame.entity.UserAccountEntity;
import com.innovationm.igotgame.exception.AppException;
import com.innovationm.igotgame.exception.BadRequestException;
import com.innovationm.igotgame.exception.EntityNotExistException;
import com.innovationm.igotgame.repository.OpportunityRepository;
import com.innovationm.igotgame.repository.OrganisationRepository;
import com.innovationm.igotgame.repository.UserAccountRepository;
import com.innovationm.igotgame.repository.UserProfileRepository;
import com.innovationm.igotgame.request.OrganisationProfileRequest;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetOrganisationDashboardResponse;
import com.innovationm.igotgame.response.GetOrganisationProfileDetailResponse;
import com.innovationm.igotgame.security.JwtTokenProvider;
import com.innovationm.igotgame.service.FileService;
import com.innovationm.igotgame.service.OrganisationService;

@Service
public class OrganisationServiceImpl implements OrganisationService{

	@Autowired
	private OrganisationRepository organisationRepository;
	@Autowired
	private UserAccountRepository userAccountRepository;
	
	@Autowired
	private UserProfileRepository userprofileRepository;
	
	@Autowired
	private OpportunityRepository opportunityRepository;
	
	@Autowired
	private FileServiceImpl fileServiceImpl;
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	@Value("${aws.s3.organisation.profile_pic}")
	private String orgProfilePath;
		
	
	
	@Override
	public CommonSuccessResponse upateOrganisationProfile(String token, OrganisationProfileRequest request, MultipartFile organisationImage) throws IOException {
		if(organisationImage!=null && !(organisationImage.getSize()<=0) && !organisationImage.getContentType().equals("image/jpeg"))
		{ 
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
				AppConstants.ErrorMessage.INVALID_FILE_FORMAT); 
		}
		if(request.getContactNo()==null || request.getContactNo()=="")
		{
			
		throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
				AppConstants.ErrorMessage.INVALID_CONTACT_NO); 
		}
		String orgEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity orgAccount=userAccountRepository.findByEmail(orgEmail).orElse(null);
		if(orgAccount==null || orgAccount.getActive()==false )
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS);
		}
		UserAccountEntity contactAcc=userAccountRepository.findByContactNo(request.getContactNo()).orElse(null);
		if(contactAcc!=null && contactAcc.getId()!=orgAccount.getId() )
		{
			throw new AppException("Contact Number already exist");
		}
		
		orgAccount.setContactNo(request.getContactNo());
		userAccountRepository.save(orgAccount);
		
		OrganisationEntity org=organisationRepository.findByUserAccountId(orgAccount.getId()).orElse(null);
		
			org.setName(request.getOrganizationName());
			org.setAbout(request.getAbout());
			org.setProfileUrl("profile url");
			org.setWebsiteUrl(request.getWebsite());
			org.setAddressLine1(request.getAddressLine1());
			org.setCountry(request.getCountry());
			org.setState(request.getState());
			org.setCity(request.getCity());
			org.setPinCode(request.getPinCode());
			org.setUserAccount(orgAccount);
			
			organisationRepository.save(org);
			if(organisationImage!=null && !(organisationImage.getSize()<=0))
			{
			String originalFileName=organisationImage.getOriginalFilename();
			String extension=originalFileName.substring(originalFileName.lastIndexOf("."));
			String filaPathPrefix=orgProfilePath;
			String filePathSuffix=orgAccount.getId()+"_Org_Profile"+extension;
			String filePath=filaPathPrefix+AppConstants.Commons.SLASH +filePathSuffix;
			fileServiceImpl.uploadFile(organisationImage, filePath);
			org.setProfileUrl(filePathSuffix);
			organisationRepository.save(org);
			}
		
		return new CommonSuccessResponse(true);
	}

	@Override
	public GetOrganisationProfileDetailResponse getOrganisationProfile(String token ) {
		String orgEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity orgAccount=userAccountRepository.findByEmail(orgEmail).orElse(null);
		if(orgAccount==null || orgAccount.getActive()==false )
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS);
		}
		OrganisationEntity org=organisationRepository.findByUserAccountId(orgAccount.getId()).orElse(null);
		if(org==null || org.getActive()==false )
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS);
		}
		
		GetOrganisationProfileDetailResponse resp= GetOrganisationProfileDetailResponse
				.builder()
				.organisationAccountId(orgAccount.getId())
				.organisationName(org.getName())
				.about(org.getAbout())
				.website(org.getWebsiteUrl())
				.profileUrl(null)
				.addressLine1(org.getAddressLine1())
				.contactNo(org.getUserAccount().getContactNo())
				.emailId(org.getUserAccount().getEmail())
				.country(org.getCountry())
				.state(org.getState())
				.city(org.getCity())
				.pinCode(org.getPinCode())
				.build();
		
		if(org.getProfileUrl()!=null)
		{
			resp.setProfileUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(orgProfilePath+AppConstants.Commons.SLASH +org.getProfileUrl()));
		}
		return resp;
	}

	@Override
	public GetOrganisationDashboardResponse getOrganisationDashboardDetail(String token) { 
		String orgEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity orgAccount=userAccountRepository.findByEmail(orgEmail).orElse(null);
		if(orgAccount==null || orgAccount.getActive()==false )
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS);
		}
		OrganisationEntity org=organisationRepository.findByUserAccountId(orgAccount.getId()).orElse(null);
		if(org==null || org.getActive()==false )
		{
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS);
		}
		GetOrganisationDashboardResponse resp= GetOrganisationDashboardResponse.builder() 
				.organisationName(org.getName())
				.organisationAccountId(orgAccount.getId())
				.activeOpportunityCount(opportunityRepository.countActiceOpportunity(org.getId()))
				.recruiterCount(userprofileRepository.countRecruiter(org.getId()))
				.candidateCount(userprofileRepository.countCandidate(org.getId()))
				.profileUrl(org.getProfileUrl())
				.addressLine1(org.getAddressLine1())
				.country(org.getCountry())
				.state(org.getState())
				.city(org.getCity())
				.pinCode(org.getPinCode())
				.build();
		if(org.getProfileUrl()!=null)
		{
			resp.setProfileUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(orgProfilePath+AppConstants.Commons.SLASH +org.getProfileUrl()));
		}
		return resp;
		
	}

}
