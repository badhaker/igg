package com.innovationm.igotgame.service.impl;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.mail.MessagingException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.innovationm.igotgame.Enum.FilterRecruiterValue;
import com.innovationm.igotgame.Enum.RecruiterStatus;
import com.innovationm.igotgame.Enum.TokenType;

import org.springframework.security.crypto.password.PasswordEncoder;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.entity.OrganisationEntity;
import com.innovationm.igotgame.entity.UserAccountEntity;
import com.innovationm.igotgame.entity.UserProfileEntity;
import com.innovationm.igotgame.entity.VerificationTokenEntity;
import com.innovationm.igotgame.exception.AppException;
import com.innovationm.igotgame.exception.BadRequestException;
import com.innovationm.igotgame.exception.EntityNotExistException;
import com.innovationm.igotgame.exception.InvalidEmailException;
import com.innovationm.igotgame.exception.UserAlreadyExistException;
import com.innovationm.igotgame.pojo.Mail;
import com.innovationm.igotgame.repository.OrganisationRepository;
import com.innovationm.igotgame.repository.UserAccountRepository;
import com.innovationm.igotgame.repository.UserProfileRepository;
import com.innovationm.igotgame.repository.UserRoleRepository;
import com.innovationm.igotgame.repository.VerificationTokenRepository;
import com.innovationm.igotgame.request.AddRecruiterRequest;
import com.innovationm.igotgame.request.RecruiterProfileRequest;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetRecruiterProfileResponse;
import com.innovationm.igotgame.response.RecruiterListResponse;
import com.innovationm.igotgame.security.JwtTokenProvider;
import com.innovationm.igotgame.service.MailingService;
import com.innovationm.igotgame.service.RecruiterService;
import com.innovationm.igotgame.util.AppUtility;

@Service
public class RecruiterServiceImpl implements RecruiterService{

	private final Logger logger = LogManager.getLogger(this.getClass());

	@Autowired
	private UserAccountRepository accountRepo;
	
	@Autowired
	private UserProfileRepository profileRepo;

	@Autowired
	private OrganisationRepository organisationRepo;
	
	@Autowired
	private UserRoleRepository roleRepo;
	
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	@Autowired
	private FileServiceImpl fileServiceImpl;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	MailingService mailingService;
	@Value("${verifyemail}")
	private String verifyemail;
	
	@Value("${aws.s3.recruiter.profile_pic}")
	private String recProfilePath;
	@Autowired
	VerificationTokenRepository verificationTokenRepository;

	
	@Override
	public CommonSuccessResponse addRecruiter(AddRecruiterRequest request, String token) throws MessagingException, IOException {
		if(request.getRecruiterEmail()==null || request.getRecruiterEmail()=="")
		{
			logger.warn(AppConstants.ErrorMessage.INVLAID_EMAIL_MESSAGE);
			throw new InvalidEmailException(AppConstants.ErrorType.INVLAID_EMAIL, AppConstants.ErrorCodes.INVLAID_EMAIL_CODE, 
					AppConstants.ErrorMessage.INVLAID_EMAIL_MESSAGE);
		}	
		String orgEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));		
		if(!(orgEmail.split("@")[1]).equals(request.getRecruiterEmail().split("@")[1]))
		{
			logger.warn(AppConstants.ErrorMessage.DOMAIN_DOES_NOT_MATCH);
			throw new EntityNotExistException(AppConstants.ErrorType.DOMAIN_DOES_NOT_MATCH_ERROR, AppConstants.ErrorCodes.DOMAIN_DOES_NOT_MATCH_ERROR_CODE, 
					AppConstants.ErrorMessage.DOMAIN_DOES_NOT_MATCH);
		
		}
		UserAccountEntity orgAccount=accountRepo.findByEmail(orgEmail).orElse(null);
		if(orgAccount==null || orgAccount.getActive()==false )
		{
			logger.warn(AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS);
			throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
					AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS);
		}
		
		boolean check=accountRepo.doesEmailExists(request.getRecruiterEmail());
		if (check) {
			logger.warn(AppConstants.ErrorMessage.USER_ALREADY_EXISTS_ERROR_MESSAGE);
			throw new UserAlreadyExistException(AppConstants.ErrorType.SIGN_UP_ERROR,
					AppConstants.ErrorCodes.USER_ALREADY_EXISTS_ERROR_CODE,
					AppConstants.ErrorMessage.USER_ALREADY_EXISTS_ERROR_MESSAGE);
		}

		String passwordGenerated=generateRandomPassword();
		UserAccountEntity account = 
				 UserAccountEntity.builder()
				.email(request.getRecruiterEmail())
				.password(passwordEncoder.encode(passwordGenerated))
				.role(roleRepo.findByName(AppConstants.Commons.ROLE_RECRUITER).get())
				.build();
		UserAccountEntity account1=accountRepo.save(account);

		UserProfileEntity profile=UserProfileEntity.builder()
				.userAccount(account1)
				.organisationEntity(organisationRepo.findByUserAccountId(orgAccount.getId()).get())
				.recruiterStatus(RecruiterStatus.ACTIVE)
				.build();
		
		profileRepo.save(profile);
		String name=request.getRecruiterEmail();
		String firstLetStr = name.substring(0, 1);
		String remLetStr = name.substring(1);
		String firstLetterCapitalizedName = firstLetStr + remLetStr;
		Mail mail=new Mail();
		mail.setSubject(AppConstants.MailConstant.RECRUITER_CREATED);
		mail.setTo(request.getRecruiterEmail());
		Map<String,Object> mailModelForStudent=new HashMap<>();
		mailModelForStudent.put("name",firstLetterCapitalizedName.split("@")[0]);  // firstLetterCapitalizedName -->getRecruiterEmail()
		String emailVerificationUrl = verifyemail + "?token=" + generateEmailConfirmationToken(request.getRecruiterEmail(),account1);
		mailModelForStudent.put(AppConstants.Common.VERIFICATION_FOR_SIGNUP,emailVerificationUrl);
		mailModelForStudent.put("email",request.getRecruiterEmail());
		mailModelForStudent.put("password",passwordGenerated);
		mail.setModel(mailModelForStudent);
		try {
		mailingService.sendMail(mail);
		}
		catch(Exception ex)
		{
			logger.warn(ex.getMessage());
			throw new AppException(AppConstants.ErrorType.EMAIL_ERROR, AppConstants.ErrorCodes.EMAIL_ERROR_CODE,
					ex.getMessage());
		}
		return new CommonSuccessResponse(true);
	}


	@Override
	public CommonSuccessResponse upateRecruiterProfile(String token, RecruiterProfileRequest request,  MultipartFile profileImage) throws IOException {
		
		if(profileImage!=null && !(profileImage.getSize()<=0) && !profileImage.getContentType().equals("image/jpeg"))
		{ 
			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
				AppConstants.ErrorMessage.INVALID_FILE_FORMAT); 
		}
		String recEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity entity=accountRepo.findByEmail(recEmail).orElse(null);
		UserProfileEntity profile=profileRepo.findByUserAccount(entity);
		profile.setAbout(request.getAbout());
		profile.setFirstName(request.getFirstName());
		profile.setLastName(request.getLastName());
		profile.setDesignation(request.getDesignation());
		profile.setAddressLine1(request.getAddressLine1());
		profile.setCountry(request.getCountry());
		profile.setState(request.getState());
		profile.setCity(request.getCity());
		profile.setPinCode(request.getPinCode());
		
		profileRepo.save(profile);
		if(profileImage!=null && !(profileImage.getSize()<=0))
		{
		String originalFileName=profileImage.getOriginalFilename();
		String extension=originalFileName.substring(originalFileName.lastIndexOf("."));
		String filaPathPrefix=recProfilePath;
		String filePathSuffix=entity.getId()+"_Rec_Profile"+extension;
		String filePath=filaPathPrefix+AppConstants.Commons.SLASH +filePathSuffix;
		fileServiceImpl.uploadFile(profileImage, filePath);
		profile.setProfileUrl(filePathSuffix);
		profileRepo.save(profile);	
		}
		return new CommonSuccessResponse(true);
	}


	@Override
	public GetRecruiterProfileResponse getProfileDetails(String token) {
		String recEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity entity=accountRepo.findByEmail(recEmail).orElse(null);	
		UserProfileEntity profile=profileRepo.findByUserAccount(entity);
		OrganisationEntity organisation=organisationRepo.findById(profile.getOrganisationEntity().getId())
				.orElseThrow(()->new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
				AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS));
		
		
		GetRecruiterProfileResponse resp= GetRecruiterProfileResponse.builder()
		.recruiterAccountId(entity.getId())
		.firstName(profile.getFirstName())
		.lastName(profile.getLastName())
		.designation(profile.getDesignation())
		.status(profile.getRecruiterStatus())
		.about(profile.getAbout())
		.imgURL(null)
		.addressLine1(profile.getAddressLine1())
		.country(profile.getCountry())
		.state(profile.getState())
		.city(profile.getCity())
		.pinCode(profile.getPinCode())
		.organisationName(organisation.getName())
		.organisationEmail(accountRepo.findById(organisation.getUserAccountId()).get().getEmail())
		.organisationContactNo(accountRepo.findById(organisation.getUserAccountId()).get().getContactNo())
		.build();
		
		if(profile.getProfileUrl()!=null)
		{
			resp.setImgURL(fileServiceImpl.generatePreSignedUrlForFileDownload(recProfilePath+AppConstants.Commons.SLASH +profile.getProfileUrl()));
		}
		return resp;
	}
	
	@Override
	public List<RecruiterListResponse> getRecruiterListByOrganisationId(String token,FilterRecruiterValue filterValue)
	{

		if(filterValue.equals(null) || filterValue.equals("")||!(filterValue==FilterRecruiterValue.ACTIVE ||filterValue==FilterRecruiterValue.INACTIVE||filterValue==FilterRecruiterValue.ALL ))
		{
			logger.warn(AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE);

			throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
					AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE);
		}
		
		String orgEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity orgAccount=accountRepo.findByEmail(orgEmail).orElse(null);
		OrganisationEntity organisation=organisationRepo.findByUserAccountId(orgAccount.getId()).orElseThrow(()->new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
				AppConstants.ErrorMessage.ORGANISATION_NOT_EXISTS));
		List<RecruiterListResponse> responseList=new ArrayList<RecruiterListResponse>();
		List<UserProfileEntity> recruiterProfileList=profileRepo.findAllByOrganisationEntity(organisation);

		if(filterValue==FilterRecruiterValue.ALL)
		{
		responseList=recruiterProfileList.stream().filter(p->p.getActive()!=false).map(profile->convertToModel(profile)).collect(Collectors.toList());
		}
		else
		{
		responseList=recruiterProfileList.stream().filter(p->p.getActive()!=false).filter(rec->rec.getRecruiterStatus().toString()==filterValue.toString()).map(profile->convertToModel(profile)).collect(Collectors.toList());
		}
		
		return responseList;
	}
	
		public RecruiterListResponse convertToModel(UserProfileEntity recruiterProfile) {
			UserAccountEntity recruiterAccount	=accountRepo.findById(recruiterProfile.getUserAccount().getId()).orElse(null);
			String name=recruiterProfile.getFirstName();
			if(recruiterProfile.getLastName()!= null)
			{
				name=recruiterProfile.getFirstName()+" "+recruiterProfile.getLastName();
			}
			
		RecruiterListResponse resp=RecruiterListResponse.builder()
		.recruiterAccountId(recruiterAccount.getId())			
		.email(recruiterAccount.getEmail())
		.name(name)
		.status(recruiterProfile.getRecruiterStatus())
		.recuriterProfileUrl(null)
		.build();
		
		if(recruiterProfile.getProfileUrl()!=null)
		{
			resp.setRecuriterProfileUrl(fileServiceImpl.generatePreSignedUrlForFileDownload(recProfilePath+AppConstants.Commons.SLASH +recruiterProfile.getProfileUrl()));
		}
		return resp;
		}


		@Override
		public CommonSuccessResponse upateRecruiterProfileStatus(RecruiterStatus profileStatus,Long recruiterAccountId) {
			
			if(!(profileStatus==RecruiterStatus.ACTIVE||profileStatus==RecruiterStatus.INACTIVE))
			{
				logger.warn(AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE);
				throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
						AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE); 
			}
			UserAccountEntity entity=accountRepo.findById(recruiterAccountId).orElse(null);
			if (entity==null || entity.getActive()==false)
			{
				logger.warn(AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
				throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
						AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
			}
			UserProfileEntity profile=profileRepo.findByUserAccount(entity);
			if (profile==null || profile.getActive()==false)   
			{
				logger.warn(AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
				throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
						AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
			}
			//System.out.println("status is:"+status);
			profile.setRecruiterStatus(profileStatus);
			profileRepo.save(profile);
			return new CommonSuccessResponse(true);
		}


		@Override
		public CommonSuccessResponse deleteRecruiterProfile( Long recruiterAccountId) {	
			
			if(recruiterAccountId==null || recruiterAccountId==0)
			{
				logger.warn(AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE);
				throw new BadRequestException(AppConstants.ErrorType.BAD_REQUEST_ERROR, AppConstants.ErrorCodes.BAD_REQUEST_CODE, 
						AppConstants.ErrorMessage.BAD_REQUEST_MESSAGE); 
			}
			UserAccountEntity entity=accountRepo.findById(recruiterAccountId).orElse(null);
			if (entity==null || entity.getActive()==false)
			{
				throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
						AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
			}
			entity.setActive(false);
			accountRepo.save(entity);
			UserProfileEntity profile=profileRepo.findByUserAccount(entity);
			if (profile==null || profile.getActive()==false)
			{
				throw new EntityNotExistException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR, AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE, 
						AppConstants.ErrorMessage.RECRUITER_NOT_EXISTS);
			}
			profile.setActive(false);
			profileRepo.save(profile);
			return new CommonSuccessResponse(true);

		}
		
		public String generateRandomPassword()
	    {
	        int len=9;
	        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%";
	        SecureRandom random = new SecureRandom();
	        StringBuilder sb = new StringBuilder();
	        for (int i = 0; i < len; i++)
	        {
	            int randomIndex = random.nextInt(chars.length());
	            sb.append(chars.charAt(randomIndex));
	        }
	        return sb.toString();
	    }
		
		public String generateEmailConfirmationToken(String email, UserAccountEntity userAccount)
		{
			 String confirmationToken=AppUtility.generateEmailVerificationToken(email, AppConstants.Commons.ROLE_RECRUITER);
			 VerificationTokenEntity verificationTokenEntity= VerificationTokenEntity.builder()
			 .confirmationToken(confirmationToken)
			 .tokenType(TokenType.EMAIL_VERIFICATION)
			 .userAccountEntity(userAccount)
			 .build();
			verificationTokenRepository.save(verificationTokenEntity);
			return confirmationToken;

 			
		}

	
	
	
	

}
