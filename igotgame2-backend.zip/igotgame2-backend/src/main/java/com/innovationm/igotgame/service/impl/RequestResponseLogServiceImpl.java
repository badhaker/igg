package com.innovationm.igotgame.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.innovationm.igotgame.bo.RequestResponseLogBo;
import com.innovationm.igotgame.converter.RequestResponseLogConverter;
import com.innovationm.igotgame.dao.RequestResponseLogDao;
import com.innovationm.igotgame.entity.RequestResponseLogEntity;
import com.innovationm.igotgame.service.RequestResponseLogService;

@Service
public class RequestResponseLogServiceImpl implements RequestResponseLogService {

	@Autowired
	RequestResponseLogDao requestResponseLogDao;
	
	@Override
	@Async
	public void logRequestResponse(RequestResponseLogBo requestResponseLogBo) {

		/**Converting from Bo to Entity**/
		RequestResponseLogEntity requestResponseLogEntity = RequestResponseLogConverter
				.convertRequestResponseLogBoToRequestResponseLogEntity(requestResponseLogBo);
		
		/**Calling Dao**/
		requestResponseLogDao.saveRequestResponseLog(requestResponseLogEntity);
	
		
	}

}
