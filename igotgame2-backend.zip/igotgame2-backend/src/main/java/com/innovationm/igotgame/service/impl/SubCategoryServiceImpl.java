package com.innovationm.igotgame.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.innovationm.igotgame.entity.MasterCategoryEntity;
import com.innovationm.igotgame.entity.MasterSubCategoryEntity;
import com.innovationm.igotgame.repository.MainCategoryRepository;
import com.innovationm.igotgame.repository.SubCategoryRepository;
import com.innovationm.igotgame.response.SubCategoryListResponse;
import com.innovationm.igotgame.service.SubCategoryService;
@Service
public class SubCategoryServiceImpl implements SubCategoryService {

	@Autowired
	private SubCategoryRepository subCategoryRepository;
	@Autowired
	private MainCategoryRepository MainCategoryRepository;
	
	
	@Override
	public List<SubCategoryListResponse> getSubCategoryListByMainCategory(Long mainCategoryId) {
		return subCategoryRepository.findAllByCategory(MainCategoryRepository.findById(mainCategoryId).orElse(null)).stream().map(cat-> convertToModel(cat)).collect(Collectors.toList());
		
	}

	private SubCategoryListResponse convertToModel(MasterSubCategoryEntity cat) {
		return SubCategoryListResponse.builder()
				.subCategoryId(cat.getId())
				.subCategoryName(cat.getName())
				.build();
	}

}
