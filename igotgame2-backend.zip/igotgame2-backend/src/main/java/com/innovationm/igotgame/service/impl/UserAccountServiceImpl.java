package com.innovationm.igotgame.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.AuthenticationFailedException;
import javax.mail.MessagingException;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.thymeleaf.spring4.SpringTemplateEngine;

import com.innovationm.igotgame.Enum.Gender;
import com.innovationm.igotgame.constant.AppConstants;
import com.innovationm.igotgame.entity.OrganisationEntity;
import com.innovationm.igotgame.entity.UserAccountEntity;
import com.innovationm.igotgame.entity.UserProfileEntity;
import com.innovationm.igotgame.entity.UserRoleEntity;
import com.innovationm.igotgame.entity.VerificationTokenEntity;
import com.innovationm.igotgame.exception.AppException;
import com.innovationm.igotgame.exception.EntityNotPresentException;
import com.innovationm.igotgame.exception.TokenAlreadyVerifiedException;
import com.innovationm.igotgame.exception.UserAlreadyExistException;
import com.innovationm.igotgame.pojo.Mail;
import com.innovationm.igotgame.repository.OrganisationRepository;
import com.innovationm.igotgame.repository.UserAccountRepository;
import com.innovationm.igotgame.repository.UserProfileRepository;
import com.innovationm.igotgame.repository.UserRoleRepository;
import com.innovationm.igotgame.repository.VerificationTokenRepository;
import com.innovationm.igotgame.request.OrganiZationSignUpRequest;
import com.innovationm.igotgame.request.SignInRequest;
import com.innovationm.igotgame.request.StudentSignUpRequest;
import com.innovationm.igotgame.response.CommonSuccessResponse;
import com.innovationm.igotgame.response.GetCommonDetailResponse;
import com.innovationm.igotgame.response.SiginResponse;
import com.innovationm.igotgame.security.JwtTokenProvider;
import com.innovationm.igotgame.security.TokenNotValidException;
import com.innovationm.igotgame.security.UserPrincipal;
import com.innovationm.igotgame.service.MailingService;
import com.innovationm.igotgame.service.UserAccountService;
import com.innovationm.igotgame.util.AppUtility;

@Service
public class UserAccountServiceImpl implements  UserAccountService{
	
	@Autowired
	private UserAccountRepository userAccountRepository;
	
	@Autowired
	private UserProfileRepository userProfileRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Value("${verifyemail}")
	private String verifyemail;
	@Autowired
	private UserRoleRepository userRoleRepository;
	@Autowired
	OrganisationRepository organisationRepository;
	@Value("${spring.mail.username}")
    private  String  empEmail;
	private JavaMailSender javaMailSender;
	@Autowired
	SpringTemplateEngine templateEngine;
	@Autowired
	MailingService mailingService;
	@Autowired
	VerificationTokenRepository verificationTokenRepository;
	@Value("${api.email-verification.expire-time}")
	private long emailVerificationExpirationTime;
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	private final Logger logger = LogManager.getLogger(this.getClass());

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		UserAccountEntity entity=userAccountRepository.findByEmail(email).orElseThrow(()->new AppException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR,
				AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE,
				AppConstants.ErrorMessage.ENTITY_NOT_EXISTS_ERROR_MESSAGE));
		UserPrincipal userPrincipal=UserPrincipal.create(entity);
		return userPrincipal;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public CommonSuccessResponse createStudent(StudentSignUpRequest request)  {
		String email=request.getEmail();
		boolean check=userAccountRepository.doesEmailExists(email);
		if (check) {
			logger.warn(AppConstants.ErrorMessage.USER_ALREADY_EXISTS_ERROR_MESSAGE);
			throw new UserAlreadyExistException(AppConstants.ErrorType.SIGN_UP_ERROR,
					AppConstants.ErrorCodes.USER_ALREADY_EXISTS_ERROR_CODE,
					AppConstants.ErrorMessage.USER_ALREADY_EXISTS_ERROR_MESSAGE);
		}
		UserRoleEntity roleEntity=userRoleRepository.findByName("CANDIDATE").orElseThrow(()->new AppException(AppConstants.ErrorType.INVALID_ROLE,
				AppConstants.ErrorCodes.INVALID_ROLE_ERROR_CODE,AppConstants.ErrorMessage.INVALID_ROLE_ERROR_MESSAGE));
	   	String verify=AppUtility.generateEmailVerificationToken(email, "CANDIDATE");
	   	System.out.println(verify); //save
		  VerificationTokenEntity  verificationTokenEntity=new VerificationTokenEntity();
		  verificationTokenEntity.setConfirmationToken(verify);
		  List<VerificationTokenEntity> tokenList=new ArrayList<>();
		  tokenList.add(verificationTokenEntity);
		UserAccountEntity userAccount= UserAccountEntity.builder()
				.email(email)
				.password(passwordEncoder.encode(request.getPassword()))
				.verificationToken(tokenList)
				.role(roleEntity)
				.build();
		UserProfileEntity userProfileEntity= UserProfileEntity.builder()
				.firstName(request.getFirstName())
				.lastName(request.getLastName())
				.gender(Gender.MALE)
				.userAccount(userAccount)
				.build();
				userProfileRepository.save(userProfileEntity);
				verificationTokenEntity.setUserAccountEntity(userAccount);
				verificationTokenRepository.save(verificationTokenEntity);
		Mail mail=new Mail();
		mail.setSubject(AppConstants.MailConstant.SIGNUP);
		mail.setTo(email);
		Map<String,Object> mailModelForStudent=new HashMap<>();
		mailModelForStudent.put("name",request.getFirstName());
		String emailVerificationUrl = verifyemail + "?token=" + verificationTokenEntity.getConfirmationToken();
		mailModelForStudent.put(AppConstants.Common.VERIFICATION_FOR_SIGNUP,emailVerificationUrl);
		mail.setModel(mailModelForStudent);
		try {
			mailingService.sendMail(mail);
		}
		catch(Exception ex)
		{
			logger.warn(ex.getMessage());
			throw new AppException(AppConstants.ErrorType.EMAIL_ERROR, AppConstants.ErrorCodes.EMAIL_ERROR_CODE,
					ex.getMessage());
		}
		return new CommonSuccessResponse(true);
	}

	@Override
	//@Transactional(rollbackOn = Exception.class)
	public CommonSuccessResponse createOrganisation(OrganiZationSignUpRequest request){
		String email=request.getEmail();
		boolean check=userAccountRepository.doesEmailExists(email);
		if (check) {
			logger.warn(AppConstants.ErrorMessage.USER_ALREADY_EXISTS_ERROR_MESSAGE);
			throw new UserAlreadyExistException(AppConstants.ErrorType.SIGN_UP_ERROR,
					AppConstants.ErrorCodes.USER_ALREADY_EXISTS_ERROR_CODE,
					AppConstants.ErrorMessage.USER_ALREADY_EXISTS_ERROR_MESSAGE);
		}
		UserRoleEntity roleEntity=userRoleRepository.findByName("ORGANISATION").orElseThrow(()->new AppException(AppConstants.ErrorType.INVALID_ROLE,
				AppConstants.ErrorCodes.INVALID_ROLE_ERROR_CODE,AppConstants.ErrorMessage.INVALID_ROLE_ERROR_MESSAGE));
			
		String verify=AppUtility.generateEmailVerificationToken(email, "ORGANISATION");
		  VerificationTokenEntity  verificationTokenEntity=new VerificationTokenEntity();
		  verificationTokenEntity.setConfirmationToken(verify);
		  List<VerificationTokenEntity> tokenList=new ArrayList<>();
		  tokenList.add(verificationTokenEntity);
		UserAccountEntity userAccount= UserAccountEntity.builder()
				.email(email)
				.password(passwordEncoder.encode(request.getPassword()))
				.verificationToken(tokenList)
				.role(roleEntity)
				.build();
				OrganisationEntity organisationEntity=new OrganisationEntity();
				organisationEntity.setName(request.getOrganisationName());
				organisationEntity.setUserAccount(userAccount);
				organisationRepository.save(organisationEntity);
				verificationTokenEntity.setUserAccountEntity(userAccount);
				verificationTokenRepository.save(verificationTokenEntity);
				String emailVerificationUrl = verifyemail + "?token=" + verificationTokenEntity.getConfirmationToken();
				Mail mail=new Mail();
				mail.setSubject(AppConstants.MailConstant.SIGNUP);
				mail.setTo(email);
				Map<String,Object> mailModelForOrganisation=new HashMap<>();
				mailModelForOrganisation.put("name",request.getOrganisationName());
				mailModelForOrganisation.put(AppConstants.Common.VERIFICATION_FOR_SIGNUP,emailVerificationUrl);
				mail.setModel(mailModelForOrganisation);
				try {
					mailingService.sendMail(mail);
				}
				catch(Exception ex)
				{
					logger.warn(ex.getMessage());
					throw new AppException(AppConstants.ErrorType.EMAIL_ERROR, AppConstants.ErrorCodes.EMAIL_ERROR_CODE,
							ex.getMessage());
				}
				
		return new CommonSuccessResponse(true);
	}

	@Override
	public CommonSuccessResponse verifyEmail(String token) {

		VerificationTokenEntity verificationTokenEntity = verificationTokenRepository.findByConfirmationToken(token)
				.orElseThrow(() -> new EntityNotPresentException(AppConstants.ErrorType.ENTITY_NOT_EXISTS_ERROR,
						AppConstants.ErrorCodes.ENTITY_NOT_EXISTS_ERROR_CODE,
						AppConstants.ErrorMessage.VERIFICATION_TOKEN_ENTITY_NOT_PRESENT));
		UserAccountEntity userAccountEntity=verificationTokenEntity.getUserAccountEntity();
		if (userAccountEntity.isEmailVerified() == true) {
			logger.warn(AppConstants.ErrorMessage.VERIFICATION_TOKEN_ALREADY_VERIFIED);
			throw new TokenAlreadyVerifiedException(AppConstants.ErrorType.VERIFICATION_TOKEN_ALREADY_VERIFIED,
					AppConstants.ErrorCodes.VERIFICATION_TOKEN_ALREADY_VERIFIED,
					AppConstants.ErrorMessage.VERIFICATION_TOKEN_ALREADY_VERIFIED);

		}
		long timeInMillsForCreatedDate = verificationTokenEntity.getUpdated().getTime();
		long expirationTime = timeInMillsForCreatedDate + emailVerificationExpirationTime;

		Date newDate = new Date(expirationTime);
		Date currentDate = new Date();

		if (newDate.before(currentDate)) // token Expired
		{
			logger.warn(AppConstants.ErrorMessage.INVALID_VERIFICATION_LINK_ERROR_MESSAGE);
			throw new TokenNotValidException(AppConstants.ErrorType.INVLAID_VERIFICATION_LINK_ERROR,
					AppConstants.ErrorCodes.INVALID_VERIFICATION_LINK_CODE,
					AppConstants.ErrorMessage.INVALID_VERIFICATION_LINK_ERROR_MESSAGE);
		}
		
		if (userAccountEntity.isEmailVerified() == false) {
			userAccountEntity.setEmailVerified(true);
		}

		verificationTokenRepository.save(verificationTokenEntity);
		return new CommonSuccessResponse(true);
	}

	@Override
	public SiginResponse signIn(SignInRequest signInRequest) {
		UserAccountEntity entity=userAccountRepository.findByEmail(signInRequest.getEmail()).orElseThrow(()->
		 new InternalAuthenticationServiceException(
				AppConstants.ErrorMessage.USER_DOES_NOT_EXISTS_ERROR_MESSAGE));
		if(!entity.isEmailVerified())
		{
			logger.warn(AppConstants.ErrorMessage.USER_NOT_VERIFIED_ERROR_MESSAGE);
		  throw new InternalAuthenticationServiceException(
				AppConstants.ErrorMessage.USER_NOT_VERIFIED_ERROR_MESSAGE);
		}
		return new SiginResponse(entity.getRole().getName());
	}

	@Override
	public GetCommonDetailResponse getCommonDetail(String token) {
		String orgEmail=jwtTokenProvider.getEmailIdFromJWT(token.substring(7));
		UserAccountEntity account=userAccountRepository.findByEmail(orgEmail).orElse(null);
		String role=userRoleRepository.findById(account.getRole().getId()).get().getName();
		String name=null;
		String email=null;

		if(role.equals("ORGANISATION"))
		{
			name=organisationRepository.findByUserAccountId(account.getId()).orElse(null).getName();		
		}
		else
		{
		UserProfileEntity profile=userProfileRepository.findByUserAccount(account);
		name=profile.getFirstName();
		if(profile.getLastName()!= null)
		{
			name=profile.getFirstName()+" "+profile.getLastName();
		}	
		}
		
		return GetCommonDetailResponse.builder()
				.AccountId(account.getId())
				.email(account.getEmail())
				.role(role)
				.name(name)
				.build();
	}

}
