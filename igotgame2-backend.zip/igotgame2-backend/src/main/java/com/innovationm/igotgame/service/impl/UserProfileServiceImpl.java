package com.innovationm.igotgame.service.impl;

import org.springframework.stereotype.Service;

import com.innovationm.igotgame.service.UserProfileService;

@Service
public class UserProfileServiceImpl implements UserProfileService{
	
}
