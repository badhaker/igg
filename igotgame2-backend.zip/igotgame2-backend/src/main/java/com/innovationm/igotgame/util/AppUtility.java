package com.innovationm.igotgame.util;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AppUtility {

	@Value("${verifyemail}")
	private String verifyemail;

	/*@Value("${resetpassword}")
	private String resetPassword;


/*	public static VerificationTokenEntity generateVerificationToken(EmployerEntity employerEntity) {
		VerificationTokenEntity verificationTokenEntity = new VerificationTokenEntity(employerEntity);
		return verificationTokenEntity;
	}
*/
/*	public static SimpleMailMessage generateSimpleMailMessage(String name, String email, String confirmationToken,
			String mailType) {

		String text = "";
		String subject = "";
		String url = "";

		if (mailType.equalsIgnoreCase(TokenType.EMAIL_VERIFICATION.toString())) {
			text = AppConstants.Mail.Text.REGISTRATION_MAIL_TEXT;
			subject = AppConstants.Mail.Subject.REGISTRATION_MAIL_SUBJECT;
			url = new AppUtility().verifyemail;
		}

		else if (mailType.equalsIgnoreCase(TokenType.RESET_PASSWORD.toString())) {
			text = AppConstants.Mail.Text.PASSWORD_RESET_MAIL_TEXT;
			subject = AppConstants.Mail.Subject.PASSWORD_RESET_MAIL_SUBJECT;
			url = new AppUtility().resetPassword;
		}

		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setTo(email);
		mailMessage.setSubject(subject);
		mailMessage.setText("Dear " + name + "," + text + url + "?token=" + confirmationToken);

		return mailMessage;
	}

	public static VerificationTokenEntity generateVerificationOtp(EmployerEntity employerEntity) {
		VerificationTokenEntity verificationTokenEntity = new VerificationTokenEntity(employerEntity);

		// generating 4 digit OTP
		String numbers = "0123456789";
		Random random = new Random();
		char[] otp = new char[4];

		for (int i = 0; i < 4; i++) {
			otp[i] = numbers.charAt(random.nextInt(numbers.length()));
		}

		String otpString = new String(otp);

		verificationTokenEntity.setConfirmationToken(otpString);
		return verificationTokenEntity;
	}

	public static long generateOtp() {

		long passCode = (long) ((Math.random() * 9000) + 1000);
		return passCode;
	}

	public static String ConvertTimeInto12HoursFormat(Date time) {
		DateFormat dateFormat = new SimpleDateFormat("hh:mm aa");
		String dateString = dateFormat.format(time).toString();
		return dateString;
	}

	public static String generateUniqueTransactionIdForPayment() {

		String unique = UUID.randomUUID().toString() + new Date().getTime();

		String uniqueID = "TXN_" + unique.substring(0, 12) + "_" + new Date().getTime();

		return uniqueID;

	}

	public static String generateInvoiceNumber() {

		int length = 12;
		boolean useLetters = false;
		boolean useNumbers = true;
		String generatedString = RandomStringUtils.random(length, useLetters, useNumbers);
		return "IN" + generatedString;
	}

	public static Date endDate(LocalDateTime startDate) {

		startDate = startDate.plusMonths(1).minusDays(1);
		Date endDate = Date.from(startDate.toInstant(ZoneOffset.UTC));
		return endDate;
	}

	public static Date startDate(LocalDateTime startDate) {

		Date endDate = Date.from(startDate.toInstant(ZoneOffset.UTC));
		return endDate;
	}
*/
	public static String generateEmailVerificationToken(String email, String userType) {

		String emailVerificationToken = UUID.randomUUID().toString()+"$"+email+"$"+ userType;
		return emailVerificationToken;
	}


}
